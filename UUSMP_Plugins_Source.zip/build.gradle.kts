// Root build file for the single combined plugin (see settings.gradle.kts).

allprojects {
    repositories {
        mavenCentral()
        maven("https://repo.papermc.io/repository/maven-public/")
    }
}

subprojects {
    apply(plugin = "java")

    // IMPORTANT — this now applies to the WHOLE combined plugin, including the
    // AirliftAlert code, which was originally spec'd for Minecraft 26.2 / Paper
    // / Java 26. Both of those are beyond what I can verify from here — my own
    // local JDK is 21 and structurally can't even target a "release 26"
    // bytecode version, and I have no way to confirm the real paper-api
    // Maven coordinate for that Paper build. The values below are safe
    // placeholders so the build succeeds while you confirm the real ones:
    // check https://repo.papermc.io/#browse/browse:maven-public:io%2Fpapermc%2Fpaper%2Fpaper-api
    // and whichever JDK distribution actually ships a "26" release, then
    // update both lines below. Since everything is now one module, there's
    // only one place to change this.
    configure<JavaPluginExtension> {
        toolchain {
            languageVersion.set(JavaLanguageVersion.of(21)) // TODO: bump to 26 once confirmed real
        }
    }

    dependencies {
        "compileOnly"("io.papermc.paper:paper-api:1.21.1-R0.1-SNAPSHOT") // TODO: update to the real MC 26.2 coordinate
    }

    tasks.withType<Jar> {
        archiveBaseName.set(project.name)
    }
}
