// Root build file for the single combined plugin (see settings.gradle.kts).

allprojects {
    repositories {
        mavenCentral()
        maven {
            name = "papermc"
            url = uri("https://repo.papermc.io/repository/maven-public/")
        }
    }
}

subprojects {
    apply(plugin = "java")

    // Confirmed via PaperMC's own current docs (docs.papermc.io/paper/dev/project-setup)
    // and the PaperMC/Paper GitHub repo: Paper switched to a new version scheme
    // starting at 26.1 — "{VERSION}.build.+" for the latest build, or a pinned
    // build like "26.2.build.119-stable". The toolchain PaperMC itself
    // documents for this is JDK 25 ("Java 25 and above" per their IntelliJ
    // plugin setup table) — not 26 as originally specified; using 25 here
    // since that's what's actually documented, though 26 should also work
    // per their own "and above" wording if you specifically need it.
    configure<JavaPluginExtension> {
        toolchain {
            languageVersion.set(JavaLanguageVersion.of(25))
        }
    }

    dependencies {
        "compileOnly"("io.papermc.paper:paper-api:26.2.build.+")
    }

    tasks.withType<Jar> {
        archiveBaseName.set(project.name)
    }
}
