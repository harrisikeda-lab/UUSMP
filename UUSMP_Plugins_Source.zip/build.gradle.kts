// Root build file. The two plugins are separate Gradle subprojects (see
// settings.gradle.kts) but share the same repositories/dependency/toolchain
// setup below, so neither subproject needs its own build.gradle.kts.

allprojects {
    repositories {
        mavenCentral()
        maven("https://repo.papermc.io/repository/maven-public/")
    }
}

subprojects {
    apply(plugin = "java")

    // IMPORTANT: this version string may not match your actual server.
    // Check https://repo.papermc.io/#browse/browse:maven-public:io%2Fpapermc%2Fpaper%2Fpaper-api
    // (or your server's own "version" command) and update this to the
    // paper-api release that matches the Paper build you actually run.
    dependencies {
        "compileOnly"("io.papermc.paper:paper-api:1.21.1-R0.1-SNAPSHOT")
    }

    configure<JavaPluginExtension> {
        toolchain {
            languageVersion.set(JavaLanguageVersion.of(21))
        }
    }

    tasks.withType<Jar> {
        archiveBaseName.set(project.name)
    }
}
