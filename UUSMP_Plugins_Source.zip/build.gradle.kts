// Root build file. The two plugins are separate Gradle subprojects (see
// settings.gradle.kts) but share the same repositories/dependency/toolchain
// setup below, so neither subproject needs its own build.gradle.kts.

allprojects {
    repositories {
        mavenCentral()
        maven("https://repo.papermc.io/repository/maven-public/")
    }
}

subprojects {
    apply(plugin = "java")

    // IMPORTANT: this version string may not match your actual server.
    // Check https://repo.papermc.io/#browse/browse:maven-public:io%2Fpapermc%2Fpaper%2Fpaper-api
    // (or your server's own "version" command) and update this to the
    // paper-api release that matches the Paper build you actually run.
    dependencies {
        "compileOnly"("io.papermc.paper:paper-api:1.21.1-R0.1-SNAPSHOT")
    }

    configure<JavaPluginExtension> {
        toolchain {
            languageVersion.set(JavaLanguageVersion.of(21))
        }
    }

    tasks.withType<Jar> {
        archiveBaseName.set(project.name)
    }
}

// AirliftAlert specifically targets Minecraft 26.2 / Paper / Java 26 per its
// spec. Java 26, and the real paper-api coordinate for Paper on MC 26.2, are
// both beyond what I can verify from here — my own local JDK is 21 and
// structurally can't even target a "release 26" bytecode version, and I have
// no way to confirm the real Maven artifact for that Paper build. The lines
// below are safe placeholders so the build succeeds while you confirm the
// real values (check https://repo.papermc.io/#browse/browse:maven-public:io%2Fpapermc%2Fpaper%2Fpaper-api
// and whichever JDK distribution actually ships a "26" release) — this
// override only touches airliftalert, not railgun-suite.
project(":airliftalert") {
    configure<JavaPluginExtension> {
        toolchain {
            languageVersion.set(JavaLanguageVersion.of(21)) // TODO: bump to 26 once confirmed real
        }
    }
    dependencies {
        "compileOnly"("io.papermc.paper:paper-api:1.21.1-R0.1-SNAPSHOT") // TODO: update to the real MC 26.2 coordinate
    }
}
