package com.craterrepair.plugin;

import org.bukkit.event.server.ServerLoadEvent;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

public class CraterRepairPlugin extends JavaPlugin {

    private CraterManager craterManager;

    @Override
    public void onEnable() {
        this.craterManager = new CraterManager(this);

        PluginManager pm = getServer().getPluginManager();
        pm.registerEvents(new BlastListener(craterManager), this);
        // Also loads pending restores here (once ALL worlds are confirmed up)
        pm.registerEvents(new ServerLoadListener(craterManager), this);

        getLogger().info("CraterRepairPlugin enabled.");
    }

    @Override
    public void onDisable() {
        craterManager.savePending();
        getLogger().info("CraterRepairPlugin disabled.");
    }

    // Small dedicated listener, kept separate so its single responsibility is obvious.
    private static class ServerLoadListener implements org.bukkit.event.Listener {
        private final CraterManager manager;

        ServerLoadListener(CraterManager manager) {
            this.manager = manager;
        }

        @org.bukkit.event.EventHandler
        public void onServerLoad(ServerLoadEvent event) {
            manager.loadPending();
        }
    }
}
