package com.craterrepair.plugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

public class CraterManager {

    private static final long REPAIR_DELAY_MILLIS = 5L * 60L * 1000L; // 5 minutes
    private static final long REPAIR_DELAY_TICKS = 5L * 60L * 20L;    // 5 minutes in ticks

    private final JavaPlugin plugin;
    private final Map<UUID, PendingRestore> pending = new LinkedHashMap<>();

    public CraterManager(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Called from the explosion listener. Snapshots the pre-explosion state of every
     * destroyed block and schedules them to be restored 5 minutes from now.
     */
    public void captureAndSchedule(List<Block> blocks) {
        if (blocks == null || blocks.isEmpty()) {
            return;
        }

        String worldName = blocks.get(0).getWorld().getName();
        List<BlockSnapshot> snapshots = new ArrayList<>();
        for (Block block : blocks) {
            snapshots.add(new BlockSnapshot(block.getX(), block.getY(), block.getZ(),
                    block.getBlockData().getAsString()));
        }

        UUID id = UUID.randomUUID();
        long dueAt = System.currentTimeMillis() + REPAIR_DELAY_MILLIS;
        PendingRestore restore = new PendingRestore(id, worldName, dueAt, snapshots);

        pending.put(id, restore);
        savePending();
        scheduleRestore(id, REPAIR_DELAY_TICKS);
    }

    private void scheduleRestore(UUID id, long delayTicks) {
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> restore(id), Math.max(1L, delayTicks));
    }

    private void restore(UUID id) {
        PendingRestore pr = pending.remove(id);
        if (pr == null) {
            return;
        }

        World world = plugin.getServer().getWorld(pr.world);
        if (world != null) {
            for (BlockSnapshot snap : pr.blocks) {
                Block block = world.getBlockAt(snap.x, snap.y, snap.z);
                BlockData data = plugin.getServer().createBlockData(snap.data);
                block.setBlockData(data, false);
            }
        }

        savePending();
    }

    /**
     * Called on ServerLoadEvent (after all worlds are up) so any restores that were
     * still pending when the server stopped/crashed pick back up where they left off.
     */
    public void loadPending() {
        File file = new File(plugin.getDataFolder(), "craters.yml");
        if (!file.exists()) {
            return;
        }

        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = config.getConfigurationSection("restores");
        if (section == null) {
            return;
        }

        long now = System.currentTimeMillis();
        for (String key : section.getKeys(false)) {
            UUID id;
            try {
                id = UUID.fromString(key);
            } catch (IllegalArgumentException e) {
                continue;
            }

            ConfigurationSection entry = section.getConfigurationSection(key);
            if (entry == null) {
                continue;
            }

            String world = entry.getString("world");
            long dueAt = entry.getLong("dueAt");
            List<String> blockLines = entry.getStringList("blocks");
            if (world == null || blockLines == null) {
                continue;
            }

            List<BlockSnapshot> snapshots = new ArrayList<>();
            for (String line : blockLines) {
                BlockSnapshot snap = BlockSnapshot.decode(line);
                if (snap != null) {
                    snapshots.add(snap);
                }
            }
            if (snapshots.isEmpty()) {
                continue;
            }

            PendingRestore restore = new PendingRestore(id, world, dueAt, snapshots);
            pending.put(id, restore);

            long remainingTicks = Math.max(1L, (dueAt - now) / 50L);
            scheduleRestore(id, remainingTicks);
        }

        plugin.getLogger().info("[CraterRepair] Resumed " + pending.size() + " pending crater repair(s).");
    }

    /**
     * Writes the full current set of pending restores to craters.yml. Called after
     * every capture and every completed restore so a crash never loses more than
     * whatever happened in that same tick.
     */
    public void savePending() {
        plugin.getDataFolder().mkdirs();
        File file = new File(plugin.getDataFolder(), "craters.yml");
        FileConfiguration config = new YamlConfiguration();

        for (PendingRestore pr : pending.values()) {
            String base = "restores." + pr.id;
            config.set(base + ".world", pr.world);
            config.set(base + ".dueAt", pr.dueAt);

            List<String> encoded = new ArrayList<>();
            for (BlockSnapshot snap : pr.blocks) {
                encoded.add(snap.encode());
            }
            config.set(base + ".blocks", encoded);
        }

        try {
            config.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("[CraterRepair] Could not save craters.yml: " + e.getMessage());
        }
    }

    private static class PendingRestore {
        final UUID id;
        final String world;
        final long dueAt;
        final List<BlockSnapshot> blocks;

        PendingRestore(UUID id, String world, long dueAt, List<BlockSnapshot> blocks) {
            this.id = id;
            this.world = world;
            this.dueAt = dueAt;
            this.blocks = blocks;
        }
    }

    private static class BlockSnapshot {
        final int x;
        final int y;
        final int z;
        final String data;

        BlockSnapshot(int x, int y, int z, String data) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.data = data;
        }

        // Encoded as "x|y|z|blockDataString" — blockDataString itself never contains '|'.
        String encode() {
            return x + "|" + y + "|" + z + "|" + data;
        }

        static BlockSnapshot decode(String line) {
            String[] parts = line.split("\\|", 4);
            if (parts.length != 4) {
                return null;
            }
            try {
                int x = Integer.parseInt(parts[0]);
                int y = Integer.parseInt(parts[1]);
                int z = Integer.parseInt(parts[2]);
                return new BlockSnapshot(x, y, z, parts[3]);
            } catch (NumberFormatException e) {
                return null;
            }
        }
    }
}
