package com.craterrepair.plugin;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityExplodeEvent;

public class BlastListener implements Listener {

    private final CraterManager manager;

    public BlastListener(CraterManager manager) {
        this.manager = manager;
    }

    // Fires for every TNT (and other entity) explosion, including all the individual
    // TNT entities the railgun's rings summon. blockList() still reflects the
    // original blocks at the moment right before they're destroyed.
    @EventHandler
    public void onEntityExplode(EntityExplodeEvent event) {
        manager.captureAndSchedule(event.blockList());
    }
}
