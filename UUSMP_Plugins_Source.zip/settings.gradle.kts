rootProject.name = "uusmp-plugins"
include("uusmp-suite")
