rootProject.name = "uusmp-plugins"
include("stasis-fixer", "crater-repair", "orbital-railgun")
