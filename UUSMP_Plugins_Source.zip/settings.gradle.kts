rootProject.name = "uusmp-plugins"
include("railgun-suite", "airliftalert")
