package com.uusmp.plugin.railgun;

import java.util.Random;

import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import com.uusmp.plugin.config.SuiteConfig;

public class RailgunFirer {

    private static final Random RANDOM = new Random();

    private final SuiteConfig config;

    public RailgunFirer(SuiteConfig config) {
        this.config = config;
    }

    public void fireStabshot(Player player) {
        Location target = raycastTarget(player);
        if (target == null) {
            return;
        }
        World world = target.getWorld();

        player.playSound(player.getEyeLocation(), Sound.ITEM_SHIELD_BREAK, 1.0f, 1.0f);

        int fuseTicks = config.getStabFuseTicks();
        double wobble = config.getStabWobble();
        int tntPerLayer = Math.max(1, config.getStabTntPerLayer());

        for (int dy = config.getStabMaxDepth(); dy >= config.getStabMinDepth(); dy--) {
            for (int i = 0; i < tntPerLayer; i++) {
                double ox = (RANDOM.nextDouble() - 0.5) * wobble;
                double oz = (RANDOM.nextDouble() - 0.5) * wobble;
                Location loc = target.clone().add(ox, dy, oz);
                world.spawn(loc, TNTPrimed.class, tnt -> tnt.setFuseTicks(fuseTicks));
            }
        }
    }

    private Location raycastTarget(Player player) {
        Location eye = player.getEyeLocation();
        World world = eye.getWorld();
        if (world == null) {
            return null;
        }

        double maxRange = config.getStabMaxRange();
        RayTraceResult result = world.rayTraceBlocks(eye, eye.getDirection(), maxRange);
        if (result != null && result.getHitPosition() != null) {
            Vector hit = result.getHitPosition();
            return new Location(world, hit.getX(), hit.getY(), hit.getZ());
        }

        Vector dir = eye.getDirection();
        return new Location(world,
                eye.getX() + dir.getX() * maxRange,
                eye.getY() + dir.getY() * maxRange,
                eye.getZ() + dir.getZ() * maxRange);
    }
}
