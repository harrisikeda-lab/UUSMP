package com.uusmp.plugin.crater;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityExplodeEvent;

public class BlastListener implements Listener {

    private final CraterManager manager;

    public BlastListener(CraterManager manager) {
        this.manager = manager;
    }

    @EventHandler
    public void onEntityExplode(EntityExplodeEvent event) {
        manager.captureAndSchedule(event.blockList());
    }
}
