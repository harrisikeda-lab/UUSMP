package com.uusmp.plugin.command;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.ArmorStand;

import com.uusmp.plugin.stasis.BobberEntityManager;
import com.uusmp.plugin.stasis.HolderRecord;

public class StasisStandsCommand implements CommandExecutor {

    private final BobberEntityManager manager;

    // Stable per-command-invocation ordering so "remove <n>" refers to the same
    // stand the player just saw in "list", without needing them to type a UUID.
    private List<String> lastListedIds = new ArrayList<>();

    public StasisStandsCommand(BobberEntityManager manager) {
        this.manager = manager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("list")) {
            return list(sender);
        }
        if (args[0].equalsIgnoreCase("remove") && args.length >= 2) {
            return remove(sender, args[1]);
        }

        sender.sendMessage("Usage: /" + label + " list | remove <number>");
        return true;
    }

    private boolean list(CommandSender sender) {
        Map<String, HolderRecord> stands = manager.getStands();
        if (stands.isEmpty()) {
            sender.sendMessage("No tracked stasis stands.");
            lastListedIds = new ArrayList<>();
            return true;
        }

        lastListedIds = new ArrayList<>(stands.keySet());
        sender.sendMessage("Tracked stasis stands (" + stands.size() + "):");

        int index = 1;
        for (String rodId : lastListedIds) {
            HolderRecord record = stands.get(rodId);
            ArmorStand stand = record.getStand();
            if (stand == null) {
                sender.sendMessage(index + ". player=" + record.getPlayerName() + " (entity missing)");
            } else {
                Location loc = stand.getLocation();
                String world = loc.getWorld() != null ? loc.getWorld().getName() : "unknown";
                sender.sendMessage(index + ". player=" + record.getPlayerName()
                        + " dimension=" + world
                        + " x=" + loc.getBlockX() + " y=" + loc.getBlockY() + " z=" + loc.getBlockZ());
            }
            index++;
        }
        return true;
    }

    private boolean remove(CommandSender sender, String indexArg) {
        int index;
        try {
            index = Integer.parseInt(indexArg);
        } catch (NumberFormatException e) {
            sender.sendMessage("Not a number: " + indexArg + ". Run 'list' first to see valid numbers.");
            return true;
        }

        if (index < 1 || index > lastListedIds.size()) {
            sender.sendMessage("No such entry. Run 'list' first to see current numbers.");
            return true;
        }

        String rodId = lastListedIds.get(index - 1);
        boolean removed = manager.removeStand(rodId);
        sender.sendMessage(removed ? "Removed stand #" + index + "." : "That stand was already gone.");
        return true;
    }
}
