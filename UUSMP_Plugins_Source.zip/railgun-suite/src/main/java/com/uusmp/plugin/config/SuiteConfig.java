package com.uusmp.plugin.config;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

public class SuiteConfig {

    private final JavaPlugin plugin;

    // Crater regen
    private long regenDelayMinutes;

    // Stab
    private int stabTntPerLayer;
    private int stabMinDepth;
    private int stabMaxDepth;
    private int stabFuseTicks;
    private double stabWobble;
    private double stabMaxRange;

    public SuiteConfig(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        FileConfiguration config = plugin.getConfig();

        regenDelayMinutes = config.getLong("regen.delay-minutes", 5L);

        stabTntPerLayer = config.getInt("stab.tnt-per-layer", 1);
        stabMinDepth = config.getInt("stab.min-depth", -250);
        stabMaxDepth = config.getInt("stab.max-depth", 1);
        stabFuseTicks = config.getInt("stab.fuse-ticks", 1);
        stabWobble = config.getDouble("stab.wobble", 0.4);
        stabMaxRange = config.getDouble("stab.max-range", 144.0);
    }

    public long getRegenDelayMinutes() {
        return regenDelayMinutes;
    }

    public int getStabTntPerLayer() {
        return stabTntPerLayer;
    }

    public int getStabMinDepth() {
        return stabMinDepth;
    }

    public int getStabMaxDepth() {
        return stabMaxDepth;
    }

    public int getStabFuseTicks() {
        return stabFuseTicks;
    }

    public double getStabWobble() {
        return stabWobble;
    }

    public double getStabMaxRange() {
        return stabMaxRange;
    }
}
