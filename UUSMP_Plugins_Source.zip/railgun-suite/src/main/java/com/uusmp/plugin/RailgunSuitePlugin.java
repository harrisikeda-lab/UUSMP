package com.uusmp.plugin;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.server.ServerLoadEvent;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import com.uusmp.plugin.command.StasisStandsCommand;
import com.uusmp.plugin.config.SuiteConfig;
import com.uusmp.plugin.crater.BlastListener;
import com.uusmp.plugin.crater.CraterManager;
import com.uusmp.plugin.railgun.RailgunFirer;
import com.uusmp.plugin.railgun.RailgunListener;
import com.uusmp.plugin.railgun.RodFactory;
import com.uusmp.plugin.stasis.BobberEntityManager;
import com.uusmp.plugin.stasis.StasisListener;

public class RailgunSuitePlugin extends JavaPlugin {

    private SuiteConfig config;
    private BobberEntityManager bobberManager;
    private CraterManager craterManager;
    private StasisStandsCommand stasisStandsCommand;

    @Override
    public void onEnable() {
        this.config = new SuiteConfig(this);
        config.load();

        this.bobberManager = new BobberEntityManager(this);
        this.craterManager = new CraterManager(this, config);

        RailgunFirer firer = new RailgunFirer(config);
        this.stasisStandsCommand = new StasisStandsCommand(bobberManager);

        PluginManager pm = getServer().getPluginManager();
        pm.registerEvents(new StasisListener(bobberManager), this);
        pm.registerEvents(new BlastListener(craterManager), this);
        pm.registerEvents(new RailgunListener(this, firer), this);
        pm.registerEvents(new LoadListener(), this);

        getServer().getScheduler().runTaskTimer(this, bobberManager::tick, 1L, 1L);

        getLogger().info("RailgunSuitePlugin enabled.");
    }

    @Override
    public void onDisable() {
        if (bobberManager != null) {
            bobberManager.clearAll();
        }
        if (craterManager != null) {
            craterManager.savePending();
        }
        getLogger().info("RailgunSuitePlugin disabled.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (label.equalsIgnoreCase("stabshot")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("Only players can use this command.");
                return true;
            }
            Player player = (Player) sender;
            player.getInventory().addItem(RodFactory.createStabRod(this));
            sender.sendMessage("Gave you a stabshot rod.");
            return true;
        }

        if (label.equalsIgnoreCase("stasisstands")) {
            return stasisStandsCommand.onCommand(sender, command, label, args);
        }

        return false;
    }

    // Loading both subsystems' saved files must wait until the whole server
    // (all worlds included) is confirmed up — see BobberEntityManager /
    // CraterManager for why looking up worlds/entities during onEnable() is unsafe.
    private class LoadListener implements Listener {
        @EventHandler
        public void onServerLoad(ServerLoadEvent event) {
            bobberManager.loadData();
            craterManager.loadPending();
        }
    }
}
