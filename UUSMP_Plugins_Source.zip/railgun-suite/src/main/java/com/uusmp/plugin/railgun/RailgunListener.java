package com.uusmp.plugin.railgun;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

public class RailgunListener implements Listener {

    private final Plugin plugin;
    private final RailgunFirer firer;

    public RailgunListener(Plugin plugin, RailgunFirer firer) {
        this.plugin = plugin;
        this.firer = firer;
    }

    @EventHandler
    public void onPlayerFish(PlayerFishEvent event) {
        if (event.getState() != PlayerFishEvent.State.FISHING) {
            return;
        }

        Player player = event.getPlayer();
        if (!isStabRod(player)) {
            return;
        }

        firer.fireStabshot(player);
    }

    private boolean isStabRod(Player player) {
        ItemStack rod = player.getInventory().getItemInMainHand();
        if (rod.getType() != Material.FISHING_ROD) {
            rod = player.getInventory().getItemInOffHand();
        }
        if (rod.getType() != Material.FISHING_ROD) {
            return false;
        }

        ItemMeta meta = rod.getItemMeta();
        if (meta == null) {
            return false;
        }

        NamespacedKey key = new NamespacedKey(plugin, RodFactory.TYPE_KEY);
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        String type = pdc.get(key, PersistentDataType.STRING);
        return RodFactory.STAB_ID.equals(type);
    }
}
