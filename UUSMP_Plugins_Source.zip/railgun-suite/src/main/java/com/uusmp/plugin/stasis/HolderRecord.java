package com.uusmp.plugin.stasis;

import org.bukkit.entity.ArmorStand;

public class HolderRecord {

    final String rodId;
    final String playerName;
    final ArmorStand stand;

    public HolderRecord(String rodId, String playerName, ArmorStand stand) {
        this.rodId = rodId;
        this.playerName = playerName;
        this.stand = stand;
    }

    public String getRodId() {
        return rodId;
    }

    public String getPlayerName() {
        return playerName;
    }

    public ArmorStand getStand() {
        return stand;
    }
}
