package com.uusmp.plugin.stasis;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerFishEvent;

public class StasisListener implements Listener {

    private final BobberEntityManager manager;

    public StasisListener(BobberEntityManager manager) {
        this.manager = manager;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerFish(PlayerFishEvent event) {
        switch (event.getState()) {
            case FISHING:
                manager.onCast(event.getPlayer(), event.getHook());
                break;
            case REEL_IN:
                manager.onReelIn(event.getPlayer());
                break;
            default:
                break;
        }
    }
}
