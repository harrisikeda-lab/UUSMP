package com.uusmp.plugin.stasis;

import java.util.UUID;

/** A hook that's been cast but hasn't settled into a stand yet. */
class PendingCast {
    final UUID hookId;
    final String playerName;

    PendingCast(UUID hookId, String playerName) {
        this.hookId = hookId;
        this.playerName = playerName;
    }
}
