package com.uusmp.plugin.stasis;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.FishHook;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

public class BobberEntityManager {

    private static final String ROD_ID_KEY = "stasis_rod_id";

    private final JavaPlugin plugin;
    private final Map<String, HolderRecord> stands = new LinkedHashMap<>();
    private final Map<String, PendingCast> hooks = new HashMap<>();

    public BobberEntityManager(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void onCast(Player player, FishHook hook) {
        String rodId = resolveRodId(player, true);
        if (rodId == null) {
            return;
        }

        HolderRecord old = stands.remove(rodId);
        if (old != null && old.getStand() != null && !old.getStand().isDead()) {
            old.getStand().remove();
        }

        hooks.put(rodId, new PendingCast(hook.getUniqueId(), player.getName()));
        plugin.getLogger().info("[Bobber] Cast tracked for " + player.getName());
    }

    public void onReelIn(Player player) {
        String rodId = resolveRodId(player, false);
        if (rodId == null) {
            plugin.getLogger().warning("[Bobber] No stand found for player=" + player.getUniqueId());
            saveData();
            return;
        }

        hooks.remove(rodId);
        HolderRecord record = stands.remove(rodId);
        if (record != null && record.getStand() != null && !record.getStand().isDead()) {
            record.getStand().remove();
            plugin.getLogger().info("[Bobber] Stand removed for player=" + player.getUniqueId());
        } else {
            plugin.getLogger().warning("[Bobber] No stand found for player=" + player.getUniqueId());
        }
        saveData();
    }

    public void tick() {
        Iterator<Map.Entry<String, PendingCast>> it = hooks.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, PendingCast> entry = it.next();
            String rodId = entry.getKey();
            PendingCast pending = entry.getValue();

            if (stands.containsKey(rodId)) {
                continue;
            }

            FishHook hook = findHook(pending.hookId);
            if (hook == null) {
                it.remove();
                continue;
            }

            if (hook.getVelocity().lengthSquared() >= 0.0025D) {
                continue;
            }

            ArmorStand stand = spawnHolder(hook.getLocation());
            stands.put(rodId, new HolderRecord(rodId, pending.playerName, stand));
            it.remove();
            plugin.getLogger().info("[Bobber] Stand spawned at " + formatLoc(hook.getLocation()));
            saveData();
        }
    }

    public void saveData() {
        plugin.getDataFolder().mkdirs();
        File file = new File(plugin.getDataFolder(), "holders.yml");
        FileConfiguration config = new YamlConfiguration();

        for (HolderRecord record : stands.values()) {
            ArmorStand stand = record.getStand();
            if (stand == null || stand.isDead()) {
                continue;
            }
            String base = "holders." + record.getRodId();
            Location loc = stand.getLocation();
            config.set(base + ".standUUID", stand.getUniqueId().toString());
            config.set(base + ".world", loc.getWorld().getName());
            config.set(base + ".x", loc.getX());
            config.set(base + ".y", loc.getY());
            config.set(base + ".z", loc.getZ());
            config.set(base + ".player", record.getPlayerName());
        }

        try {
            config.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("[Bobber] Could not save holders.yml: " + e.getMessage());
        }
    }

    public void loadData() {
        File file = new File(plugin.getDataFolder(), "holders.yml");
        if (!file.exists()) {
            return;
        }

        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = config.getConfigurationSection("holders");
        if (section == null) {
            return;
        }

        boolean dirty = false;
        for (String key : section.getKeys(false)) {
            try {
                UUID.fromString(key);
            } catch (IllegalArgumentException e) {
                dirty = true;
                continue;
            }

            ConfigurationSection entry = section.getConfigurationSection(key);
            if (entry == null) {
                continue;
            }

            String worldName = entry.getString("world");
            String standUUID = entry.getString("standUUID");
            String playerName = entry.getString("player");
            double x = entry.getDouble("x");
            double z = entry.getDouble("z");

            if (worldName == null || standUUID == null) {
                dirty = true;
                continue;
            }

            World world = plugin.getServer().getWorld(worldName);
            if (world == null) {
                dirty = true;
                continue;
            }

            Chunk chunk = world.getChunkAt((int) x >> 4, (int) z >> 4);
            if (!chunk.isLoaded()) {
                chunk.load();
            }

            UUID standId;
            try {
                standId = UUID.fromString(standUUID);
            } catch (IllegalArgumentException e) {
                dirty = true;
                continue;
            }

            Entity entity = world.getEntity(standId);
            if (!(entity instanceof ArmorStand)) {
                dirty = true;
                continue;
            }
            ArmorStand stand = (ArmorStand) entity;

            stands.put(key, new HolderRecord(key, playerName != null ? playerName : "unknown", stand));
            plugin.getLogger().info("[Bobber] Restored stand for " + key);
        }

        if (dirty) {
            saveData();
        }
    }

    public void clearAll() {
        saveData();
        stands.clear();
        hooks.clear();
    }

    /** Read-only snapshot for the admin command. */
    public Map<String, HolderRecord> getStands() {
        return stands;
    }

    /** Removes a tracked stand (by its rod id) both from the world and from tracking. */
    public boolean removeStand(String rodId) {
        HolderRecord record = stands.remove(rodId);
        if (record == null) {
            return false;
        }
        if (record.getStand() != null && !record.getStand().isDead()) {
            record.getStand().remove();
        }
        saveData();
        return true;
    }

    private FishHook findHook(UUID hookUUID) {
        for (World world : plugin.getServer().getWorlds()) {
            Entity entity = world.getEntity(hookUUID);
            if (entity instanceof FishHook) {
                return (FishHook) entity;
            }
        }
        return null;
    }

    private ArmorStand spawnHolder(Location location) {
        return location.getWorld().spawn(location, ArmorStand.class, (ArmorStand as) -> {
            as.setVisible(false);
            as.setGravity(false);
            as.setMarker(false);
            as.setPersistent(true);
            as.setInvulnerable(true);
            as.setCollidable(false);
            as.setSilent(true);
            as.setSmall(false);
            as.addScoreboardTag("bobber_holder");
        });
    }

    private String formatLoc(Location loc) {
        return loc.getWorld().getName() + " " + loc.getBlockX() + "," + loc.getBlockY() + "," + loc.getBlockZ();
    }

    private String resolveRodId(Player player, boolean assignIfMissing) {
        boolean mainHand = true;
        ItemStack rod = player.getInventory().getItemInMainHand();
        if (rod.getType() != Material.FISHING_ROD) {
            rod = player.getInventory().getItemInOffHand();
            mainHand = false;
        }
        if (rod.getType() != Material.FISHING_ROD) {
            return null;
        }

        ItemMeta meta = rod.getItemMeta();
        if (meta == null) {
            return null;
        }

        NamespacedKey key = new NamespacedKey(plugin, ROD_ID_KEY);
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        String id = pdc.get(key, PersistentDataType.STRING);

        if (id == null) {
            if (!assignIfMissing) {
                return null;
            }
            id = UUID.randomUUID().toString();
            pdc.set(key, PersistentDataType.STRING, id);
            rod.setItemMeta(meta);
            if (mainHand) {
                player.getInventory().setItemInMainHand(rod);
            } else {
                player.getInventory().setItemInOffHand(rod);
            }
        }

        return id;
    }
}
