package com.uusmp.plugin.crater;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import com.uusmp.plugin.config.SuiteConfig;

public class CraterManager {

    private final JavaPlugin plugin;
    private final SuiteConfig config;
    private final Map<UUID, PendingRestore> pending = new LinkedHashMap<>();

    public CraterManager(JavaPlugin plugin, SuiteConfig config) {
        this.plugin = plugin;
        this.config = config;
    }

    public void captureAndSchedule(List<Block> blocks) {
        if (blocks == null || blocks.isEmpty()) {
            return;
        }

        String worldName = blocks.get(0).getWorld().getName();
        List<BlockSnapshot> snapshots = new ArrayList<>();
        for (Block block : blocks) {
            snapshots.add(new BlockSnapshot(block.getX(), block.getY(), block.getZ(),
                    block.getBlockData().getAsString()));
        }

        UUID id = UUID.randomUUID();
        long delayMillis = config.getRegenDelayMinutes() * 60L * 1000L;
        long dueAt = System.currentTimeMillis() + delayMillis;
        PendingRestore restore = new PendingRestore(id, worldName, dueAt, snapshots);

        pending.put(id, restore);
        savePending();
        scheduleRestore(id, ticksFromNow(dueAt));
    }

    private long ticksFromNow(long dueAtMillis) {
        return Math.max(1L, (dueAtMillis - System.currentTimeMillis()) / 50L);
    }

    private void scheduleRestore(UUID id, long delayTicks) {
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> restore(id), Math.max(1L, delayTicks));
    }

    private void restore(UUID id) {
        PendingRestore pr = pending.remove(id);
        if (pr == null) {
            return;
        }

        World world = plugin.getServer().getWorld(pr.world);
        if (world != null) {
            for (BlockSnapshot snap : pr.blocks) {
                Block block = world.getBlockAt(snap.x, snap.y, snap.z);
                BlockData data = plugin.getServer().createBlockData(snap.data);
                block.setBlockData(data, false);
            }
        }

        savePending();
    }

    public void loadPending() {
        File file = new File(plugin.getDataFolder(), "craters.yml");
        if (!file.exists()) {
            return;
        }

        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = yaml.getConfigurationSection("restores");
        if (section == null) {
            return;
        }

        for (String key : section.getKeys(false)) {
            UUID id;
            try {
                id = UUID.fromString(key);
            } catch (IllegalArgumentException e) {
                continue;
            }

            ConfigurationSection entry = section.getConfigurationSection(key);
            if (entry == null) {
                continue;
            }

            String world = entry.getString("world");
            long dueAt = entry.getLong("dueAt");
            List<String> blockLines = entry.getStringList("blocks");
            if (world == null || blockLines == null) {
                continue;
            }

            List<BlockSnapshot> snapshots = new ArrayList<>();
            for (String line : blockLines) {
                BlockSnapshot snap = BlockSnapshot.decode(line);
                if (snap != null) {
                    snapshots.add(snap);
                }
            }
            if (snapshots.isEmpty()) {
                continue;
            }

            PendingRestore restore = new PendingRestore(id, world, dueAt, snapshots);
            pending.put(id, restore);
            scheduleRestore(id, ticksFromNow(dueAt));
        }

        plugin.getLogger().info("[CraterRepair] Resumed " + pending.size() + " pending crater repair(s).");
    }

    public void savePending() {
        plugin.getDataFolder().mkdirs();
        File file = new File(plugin.getDataFolder(), "craters.yml");
        FileConfiguration config = new YamlConfiguration();

        for (PendingRestore pr : pending.values()) {
            String base = "restores." + pr.id;
            config.set(base + ".world", pr.world);
            config.set(base + ".dueAt", pr.dueAt);

            List<String> encoded = new ArrayList<>();
            for (BlockSnapshot snap : pr.blocks) {
                encoded.add(snap.encode());
            }
            config.set(base + ".blocks", encoded);
        }

        try {
            config.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("[CraterRepair] Could not save craters.yml: " + e.getMessage());
        }
    }

    private static class PendingRestore {
        final UUID id;
        final String world;
        final long dueAt;
        final List<BlockSnapshot> blocks;

        PendingRestore(UUID id, String world, long dueAt, List<BlockSnapshot> blocks) {
            this.id = id;
            this.world = world;
            this.dueAt = dueAt;
            this.blocks = blocks;
        }
    }

    private static class BlockSnapshot {
        final int x;
        final int y;
        final int z;
        final String data;

        BlockSnapshot(int x, int y, int z, String data) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.data = data;
        }

        String encode() {
            return x + "|" + y + "|" + z + "|" + data;
        }

        static BlockSnapshot decode(String line) {
            String[] parts = line.split("\\|", 4);
            if (parts.length != 4) {
                return null;
            }
            try {
                int x = Integer.parseInt(parts[0]);
                int y = Integer.parseInt(parts[1]);
                int z = Integer.parseInt(parts[2]);
                return new BlockSnapshot(x, y, z, parts[3]);
            } catch (NumberFormatException e) {
                return null;
            }
        }
    }
}
