package com.uusmp.plugin.airliftalert;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * destinations.yml — optional predefined destinations (with coordinates, for
 * future use like map markers). Kept separate from config.yml since this
 * list can grow arbitrarily long without touching feature toggles, and from
 * messages.yml since it's data, not player-facing text.
 *
 * Any typed destination name still works even if it isn't in this file —
 * this only adds coordinates when a name happens to match a configured one.
 */
public class DestinationsConfig {

    private final JavaPlugin plugin;
    private final Map<String, Destination> byNormalizedName = new LinkedHashMap<>();

    public DestinationsConfig(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        plugin.saveResource("destinations.yml", false);
        File file = new File(plugin.getDataFolder(), "destinations.yml");
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);

        byNormalizedName.clear();
        ConfigurationSection section = yaml.getConfigurationSection("destinations");
        if (section == null) {
            return;
        }

        for (String key : section.getKeys(false)) {
            ConfigurationSection entry = section.getConfigurationSection(key);
            if (entry == null) {
                continue;
            }

            String name = entry.getString("name");
            if (name == null) {
                name = key;
            }
            String world = entry.getString("world");
            double x = entry.getDouble("x");
            double y = entry.getDouble("y");
            double z = entry.getDouble("z");

            Destination destination = new Destination(name, world, x, y, z);
            byNormalizedName.put(normalize(name), destination);
        }
    }

    /** Resolves a typed destination name, filling in coordinates if it matches a configured one. */
    public Destination resolve(String typedName) {
        Destination configured = byNormalizedName.get(normalize(typedName));
        if (configured != null) {
            return configured;
        }
        return new Destination(typedName);
    }

    /** Display names of all configured destinations, for tab completion. */
    public List<String> getConfiguredNames() {
        List<String> names = new ArrayList<>();
        for (Destination destination : byNormalizedName.values()) {
            names.add(destination.getName());
        }
        return names;
    }

    private String normalize(String name) {
        return name.trim().toLowerCase();
    }
}
