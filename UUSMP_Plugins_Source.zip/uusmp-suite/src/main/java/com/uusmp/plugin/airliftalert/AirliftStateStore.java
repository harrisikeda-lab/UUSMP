package com.uusmp.plugin.airliftalert;

import java.io.File;
import java.io.IOException;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * airliftstate.yml — NOT a settings file (see the other *Config classes for
 * those); this just remembers the currently active airlift (if any) so a
 * server restart doesn't silently lose or duplicate it.
 */
public class AirliftStateStore {

    private final JavaPlugin plugin;

    public AirliftStateStore(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void save(AirliftSession session) {
        plugin.getDataFolder().mkdirs();
        File file = new File(plugin.getDataFolder(), "airliftstate.yml");
        FileConfiguration config = new YamlConfiguration();

        if (session != null) {
            config.set("destination", session.getDestination().getName());
            config.set("startTime", session.getStartTimeMillis());
            config.set("endTime", session.getEndTimeMillis());
            config.set("state", session.getState().name());
        }

        try {
            config.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("[AirliftAlert] Could not save airliftstate.yml: " + e.getMessage());
        }
    }

    public void clear() {
        save(null);
    }

    /** Returns the persisted session, or null if none was active. */
    public AirliftSession load() {
        File file = new File(plugin.getDataFolder(), "airliftstate.yml");
        if (!file.exists()) {
            return null;
        }

        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        String destinationName = config.getString("destination");
        String stateName = config.getString("state");
        if (destinationName == null || stateName == null) {
            return null;
        }

        AirliftState state;
        try {
            state = AirliftState.valueOf(stateName);
        } catch (IllegalArgumentException e) {
            return null;
        }

        if (state != AirliftState.COUNTDOWN) {
            return null;
        }

        long startTime = config.getLong("startTime");
        long endTime = config.getLong("endTime");

        AirliftSession session = new AirliftSession(new Destination(destinationName), startTime, endTime);
        session.setState(state);
        return session;
    }
}
