package com.uusmp.plugin.airliftalert;

import java.io.File;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * messages.yml — every piece of player-facing text, kept out of config.yml
 * so an admin can restyle wording/colors without touching feature toggles.
 * All values support MiniMessage tags (e.g. <red><bold>...</bold></red>)
 * and the placeholders {destination}, {minutes}, {seconds}, {time}.
 */
public class MessagesConfig {

    private final JavaPlugin plugin;
    private final MiniMessage miniMessage = MiniMessage.miniMessage();
    private YamlConfiguration yaml;

    public MessagesConfig(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        plugin.saveResource("messages.yml", false);
        File file = new File(plugin.getDataFolder(), "messages.yml");
        yaml = YamlConfiguration.loadConfiguration(file);
    }

    private String raw(String path, String fallback) {
        String value = yaml.getString(path);
        return value != null ? value : fallback;
    }

    /** Formats "5 minutes" / "1 minute" for the {time} placeholder. */
    public static String formatMinutesWord(int minutes) {
        return minutes == 1 ? "1 minute" : minutes + " minutes";
    }

    /** Formats "MM:SS" for the status command's countdown clock. */
    public static String formatClock(long totalSeconds) {
        long clamped = Math.max(0, totalSeconds);
        long minutes = clamped / 60;
        long seconds = clamped % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }

    private String applyPlaceholders(String template, String destination, int minutes, int seconds, String time) {
        String result = template;
        if (destination != null) {
            result = result.replace("{destination}", destination);
        }
        result = result.replace("{minutes}", String.valueOf(minutes));
        result = result.replace("{seconds}", String.valueOf(seconds));
        if (time != null) {
            result = result.replace("{time}", time);
        }
        return result;
    }

    private Component render(String path, String fallback, String destination, int minutes, int seconds, String time) {
        String template = raw(path, fallback);
        String withPlaceholders = applyPlaceholders(template, destination, minutes, seconds, time);
        return miniMessage.deserialize(withPlaceholders);
    }

    // --- Incoming ---

    public Component incomingTitle(String destinationUpper) {
        return render("incoming.title", "<red><bold>\uD83D\uDEA8 AIRLIFT INCOMING \uD83D\uDEA8</bold></red>",
                destinationUpper, 0, 0, null);
    }

    public Component incomingSubtitle(String destinationUpper) {
        return render("incoming.subtitle", "<gray>LANDING AT: {destination}</gray>",
                destinationUpper, 0, 0, null);
    }

    public Component incomingChat(String destination, int minutes) {
        return render("incoming.chat",
                "<red><bold>\uD83D\uDE81 AIRLIFT INCOMING</bold></red>\n\n"
                        + "<gray>Landing location: {destination}\nETA: {minutes} minutes</gray>",
                destination, minutes, 0, null);
    }

    // --- Countdown ---

    public Component countdownTitle(String destinationUpper, int minutesRemaining) {
        return render("countdown.title", "<red><bold>\uD83D\uDEA8 AIRLIFT IN {time}</bold></red>",
                destinationUpper, minutesRemaining, 0, formatMinutesWord(minutesRemaining));
    }

    public Component countdownSubtitle(String destinationUpper) {
        return render("countdown.subtitle", "<gray>LANDING AT: {destination}</gray>",
                destinationUpper, 0, 0, null);
    }

    // --- Arrived ---

    public Component arrivedTitle(String destinationUpper) {
        return render("arrived.title", "<green><bold>\uD83D\uDE81 AIRLIFT HAS ARRIVED</bold></green>",
                destinationUpper, 0, 0, null);
    }

    public Component arrivedSubtitle(String destinationUpper) {
        return render("arrived.subtitle", "<gray>LANDING AT: {destination}</gray>",
                destinationUpper, 0, 0, null);
    }

    public Component arrivedChat(String destination) {
        return render("arrived.chat",
                "<green><bold>\uD83D\uDE81 AIRLIFT HAS ARRIVED</bold></green>\n\n"
                        + "<gray>Landing location: {destination}\nBOARD NOW</gray>",
                destination, 0, 0, null);
    }

    // --- Cancelled ---

    public Component cancelledTitle() {
        return render("cancelled.title", "<red><bold>\uD83D\uDEA8 AIRLIFT CANCELLED</bold></red>",
                null, 0, 0, null);
    }

    public Component cancelledChatWithDestination(String destination) {
        return render("cancelled.chat-with-destination", "<gray>Destination: {destination}</gray>",
                destination, 0, 0, null);
    }

    // --- Status ---

    public Component statusActive(String destination, long remainingSeconds) {
        return render("status.active",
                "<gold>Airlift Status: COUNTDOWN\nTime Remaining: {time}\nDestination: {destination}</gold>",
                destination, 0, 0, formatClock(remainingSeconds));
    }

    public Component statusInactive() {
        return render("status.inactive", "<gray>Airlift Status: INACTIVE</gray>", null, 0, 0, null);
    }

    // --- Errors ---

    public Component errorAlreadyActive() {
        return render("errors.already-active",
                "<red>An airlift is already active.\nUse /airlift cancel first.</red>", null, 0, 0, null);
    }

    public Component errorNoActiveAirlift() {
        return render("errors.no-active-airlift", "<red>There is no active airlift.</red>", null, 0, 0, null);
    }

    public Component errorNoPermission() {
        return render("errors.no-permission", "<red>You do not have permission to do that.</red>", null, 0, 0, null);
    }

    public Component errorInvalidMinutes() {
        return render("errors.invalid-minutes", "<red>Minutes must be a positive number.</red>", null, 0, 0, null);
    }

    public Component errorUsage() {
        return render("errors.usage", "<red>Usage: /airlift <minutes> <destination></red>", null, 0, 0, null);
    }

    // --- Help ---

    public Component helpHeader() {
        return render("help.header", "<gold><bold>Airlift Commands:</bold></gold>", null, 0, 0, null);
    }

    public java.util.List<Component> helpLines() {
        java.util.List<String> lines = yaml.getStringList("help.lines");
        java.util.List<Component> rendered = new java.util.ArrayList<>();
        if (lines == null || lines.isEmpty()) {
            lines = java.util.List.of(
                    "<yellow>/airlift <minutes> <destination></yellow> <gray>- Start an airlift.</gray>",
                    "<yellow>/airlift arrived</yellow> <gray>- Announce that the airlift has arrived.</gray>",
                    "<yellow>/airlift cancel</yellow> <gray>- Cancel the active airlift.</gray>",
                    "<yellow>/airlift status</yellow> <gray>- Show the current airlift.</gray>",
                    "<yellow>/airlift help</yellow> <gray>- Show this help.</gray>"
            );
        }
        for (String line : lines) {
            rendered.add(miniMessage.deserialize(line));
        }
        return rendered;
    }
}
