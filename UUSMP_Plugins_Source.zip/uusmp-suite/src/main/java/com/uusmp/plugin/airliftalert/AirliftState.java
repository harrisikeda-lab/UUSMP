package com.uusmp.plugin.airliftalert;

public enum AirliftState {
    INACTIVE,
    COUNTDOWN,
    ARRIVED,
    CANCELLED
}
