package com.uusmp.plugin;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.server.ServerLoadEvent;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import com.uusmp.plugin.airliftalert.AirliftCommand;
import com.uusmp.plugin.airliftalert.AirliftManager;
import com.uusmp.plugin.airliftalert.AirliftStateStore;
import com.uusmp.plugin.airliftalert.DestinationsConfig;
import com.uusmp.plugin.airliftalert.MessagesConfig;
import com.uusmp.plugin.airliftalert.NametagManager;
import com.uusmp.plugin.airliftalert.SoundsConfig;
import com.uusmp.plugin.command.StasisStandsCommand;
import com.uusmp.plugin.config.SuiteConfig;
import com.uusmp.plugin.crater.BlastListener;
import com.uusmp.plugin.crater.CraterManager;
import com.uusmp.plugin.railgun.RailgunFirer;
import com.uusmp.plugin.railgun.RailgunListener;
import com.uusmp.plugin.railgun.RodFactory;
import com.uusmp.plugin.stasis.BobberEntityManager;
import com.uusmp.plugin.stasis.StasisListener;

/**
 * NOTE on a real behavioral interaction, not a bug: both the stasis system
 * and the railgun system listen to the same PlayerFishEvent independently.
 * Stasis's onCast() fires for ANY fishing rod cast (that's its whole job —
 * AFK fishing farms use plain rods), while the railgun's stab listener only
 * reacts to rods tagged "stabshot". This means casting a stab rod will ALSO
 * get a stasis tracking tag assigned and (once the hook settles or is
 * destroyed by the explosion) attempt its own armor-stand tracking, on top
 * of firing the stab. That was already true when these were separate jars —
 * combining them into one jar doesn't change it, since they were always
 * independent listeners on the same event. Flagging it here because it's
 * exactly the kind of thing that's easy to miss once everything shares one
 * event stream in one plugin. Let me know if you want stab rods excluded
 * from stasis tracking.
 */
public class UUSMPSuitePlugin extends JavaPlugin {

    private SuiteConfig config;

    private BobberEntityManager bobberManager;
    private CraterManager craterManager;
    private StasisStandsCommand stasisStandsCommand;

    private MessagesConfig messagesConfig;
    private SoundsConfig soundsConfig;
    private DestinationsConfig destinationsConfig;
    private AirliftStateStore airliftStateStore;
    private AirliftManager airliftManager;
    private AirliftCommand airliftCommand;
    private NametagManager nametagManager;

    @Override
    public void onEnable() {
        config = new SuiteConfig(this);
        config.load();

        // --- Stasis / Crater / Railgun (stab) ---
        bobberManager = new BobberEntityManager(this);
        craterManager = new CraterManager(this, config);
        stasisStandsCommand = new StasisStandsCommand(bobberManager);
        RailgunFirer firer = new RailgunFirer(config);

        // --- AirliftAlert ---
        messagesConfig = new MessagesConfig(this);
        messagesConfig.load();
        soundsConfig = new SoundsConfig(this);
        soundsConfig.load();
        destinationsConfig = new DestinationsConfig(this);
        destinationsConfig.load();
        airliftStateStore = new AirliftStateStore(this);
        airliftManager = new AirliftManager(this, config, messagesConfig, soundsConfig,
                destinationsConfig, airliftStateStore);
        airliftCommand = new AirliftCommand(airliftManager, config, messagesConfig);
        nametagManager = new NametagManager(this);

        PluginManager pm = getServer().getPluginManager();
        pm.registerEvents(new StasisListener(bobberManager), this);
        pm.registerEvents(new BlastListener(craterManager), this);
        pm.registerEvents(new RailgunListener(this, firer), this);
        pm.registerEvents(new LoadListener(), this);
        pm.registerEvents(new JoinListener(), this);

        getServer().getScheduler().runTaskTimer(this, bobberManager::tick, 1L, 1L);

        if (getCommand("airlift") != null) {
            getCommand("airlift").setTabCompleter(airliftCommand);
        }

        getLogger().info("UUSMPSuitePlugin enabled.");
    }

    @Override
    public void onDisable() {
        if (bobberManager != null) {
            bobberManager.clearAll();
        }
        if (craterManager != null) {
            craterManager.savePending();
        }
        if (airliftManager != null) {
            airliftManager.shutdown();
        }
        if (nametagManager != null) {
            nametagManager.disable();
        }
        getLogger().info("UUSMPSuitePlugin disabled.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (label.equalsIgnoreCase("stabshot")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("Only players can use this command.");
                return true;
            }
            Player player = (Player) sender;
            player.getInventory().addItem(RodFactory.createStabRod(this));
            sender.sendMessage("Gave you a stabshot rod.");
            return true;
        }

        if (label.equalsIgnoreCase("stasisstands")) {
            return stasisStandsCommand.onCommand(sender, command, label, args);
        }

        if (label.equalsIgnoreCase("airlift")) {
            return airliftCommand.onCommand(sender, command, label, args);
        }

        return false;
    }

    // Loading holders.yml, craters.yml, and airliftstate.yml, plus setting up
    // the nametag team, all need worlds/entities available — unsafe during
    // onEnable(). ServerLoadEvent fires only after the whole server (all
    // worlds included) is confirmed up.
    private class LoadListener implements Listener {
        @EventHandler
        public void onServerLoad(ServerLoadEvent event) {
            bobberManager.loadData();
            craterManager.loadPending();
            airliftManager.restoreFromDisk();
            if (config.isHideNametags()) {
                nametagManager.enable();
            }
        }
    }

    private class JoinListener implements Listener {
        @EventHandler
        public void onPlayerJoin(PlayerJoinEvent event) {
            if (config.isHideNametags()) {
                nametagManager.addPlayer(event.getPlayer());
            }
        }
    }
}
