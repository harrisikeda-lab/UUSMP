package com.uusmp.plugin.railgun;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

public class RodFactory {

    static final String TYPE_KEY = "railgun_type";
    static final String STAB_ID = "stabshot";

    public static ItemStack createStabRod(Plugin plugin) {
        ItemStack rod = new ItemStack(Material.FISHING_ROD, 1);
        ItemMeta meta = rod.getItemMeta();

        meta.displayName(Component.text(STAB_ID).decoration(TextDecoration.ITALIC, true));

        Enchantment mending = Registry.ENCHANTMENT.get(NamespacedKey.minecraft("mending"));
        Enchantment unbreaking = Registry.ENCHANTMENT.get(NamespacedKey.minecraft("unbreaking"));
        meta.addEnchant(mending, 1, true);
        meta.addEnchant(unbreaking, 3, true);

        // Fixed namespace (not tied to plugin.getName()) — see BobberEntityManager
        // for why: a rod tagged by an older-named jar must stay recognized.
        NamespacedKey key = new NamespacedKey("uusmp", TYPE_KEY);
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        pdc.set(key, PersistentDataType.STRING, STAB_ID);

        rod.setItemMeta(meta);
        return rod;
    }
}
