package com.uusmp.plugin.airliftalert;

import java.util.ArrayList;
import java.util.List;

import net.kyori.adventure.text.Component;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import com.uusmp.plugin.config.SuiteConfig;

public class AirliftCommand implements CommandExecutor, TabCompleter {

    private static final String PERMISSION_ADMIN = "airlift.admin";
    private static final String PERMISSION_STATUS = "airlift.status";

    private final AirliftManager manager;
    private final SuiteConfig config;
    private final MessagesConfig messages;

    public AirliftCommand(AirliftManager manager, SuiteConfig config, MessagesConfig messages) {
        this.manager = manager;
        this.config = config;
        this.messages = messages;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!config.isAirliftEnabled()) {
            return true;
        }

        if (args.length == 0) {
            sender.sendMessage(messages.errorUsage());
            return true;
        }

        String sub = args[0].toLowerCase();

        if (sub.equals("help")) {
            sendHelp(sender);
            return true;
        }

        if (sub.equals("status")) {
            if (!hasAccess(sender, PERMISSION_STATUS, PERMISSION_ADMIN)) {
                sender.sendMessage(messages.errorNoPermission());
                return true;
            }
            manager.status(sender);
            return true;
        }

        if (sub.equals("arrived")) {
            if (!hasAccess(sender, PERMISSION_ADMIN)) {
                sender.sendMessage(messages.errorNoPermission());
                return true;
            }
            manager.arrived(sender);
            return true;
        }

        if (sub.equals("cancel")) {
            if (!hasAccess(sender, PERMISSION_ADMIN)) {
                sender.sendMessage(messages.errorNoPermission());
                return true;
            }
            manager.cancel(sender);
            return true;
        }

        // Otherwise: "/airlift <minutes> <destination...>"
        if (!hasAccess(sender, PERMISSION_ADMIN)) {
            sender.sendMessage(messages.errorNoPermission());
            return true;
        }

        int minutes;
        try {
            minutes = Integer.parseInt(args[0]);
        } catch (NumberFormatException e) {
            sender.sendMessage(messages.errorUsage());
            return true;
        }

        if (minutes <= 0) {
            sender.sendMessage(messages.errorInvalidMinutes());
            return true;
        }

        if (args.length < 2) {
            sender.sendMessage(messages.errorUsage());
            return true;
        }

        String destination = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));
        manager.start(sender, minutes, destination);
        return true;
    }

    private boolean hasAccess(CommandSender sender, String... anyOf) {
        if (!config.isAirliftRequirePermission()) {
            return true;
        }
        for (String permission : anyOf) {
            if (sender.hasPermission(permission)) {
                return true;
            }
        }
        return false;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(messages.helpHeader());
        for (Component line : messages.helpLines()) {
            sender.sendMessage(line);
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        List<String> suggestions = new ArrayList<>();

        if (args.length == 1) {
            suggestions.add("arrived");
            suggestions.add("cancel");
            suggestions.add("status");
            suggestions.add("help");
            suggestions.add("5");
            suggestions.add("10");
            return suggestions;
        }

        if (args.length == 2) {
            try {
                Integer.parseInt(args[0]);
                suggestions.addAll(manager.getConfiguredDestinationNames());
            } catch (NumberFormatException ignored) {
                // First arg isn't a number — not the start-airlift form, nothing to suggest here.
            }
        }

        return suggestions;
    }
}
