package com.uusmp.plugin.config;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Single config.yml for the whole combined plugin. Settings are grouped by
 * subsystem (regen / stab / airlift / nametags) as top-level sections in the
 * same file, so there's one place to look for every toggle — but see
 * messages.yml, sounds.yml, and destinations.yml for AirliftAlert's text,
 * sounds, and destination data respectively, kept separate since those are
 * a different kind of content (player-facing text/data, not toggles).
 */
public class SuiteConfig {

    private final JavaPlugin plugin;

    // Crater regen
    private long regenDelayMinutes;

    // Stab
    private int stabTntPerLayer;
    private int stabMinDepth;
    private int stabMaxDepth;
    private int stabFuseTicks;
    private double stabWobble;
    private double stabMaxRange;

    // Airlift
    private boolean airliftEnabled;
    private boolean airliftTitleEnabled;
    private boolean airliftChatEnabled;
    private boolean airliftSoundEnabled;
    private boolean airliftAnnounceEveryMinute;
    private boolean airliftRequirePermission;
    private boolean airliftAllowMultiple;

    // Nametags
    private boolean hideNametags;

    public SuiteConfig(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        FileConfiguration config = plugin.getConfig();

        regenDelayMinutes = config.getLong("regen.delay-minutes", 5L);

        stabTntPerLayer = config.getInt("stab.tnt-per-layer", 1);
        stabMinDepth = config.getInt("stab.min-depth", -250);
        stabMaxDepth = config.getInt("stab.max-depth", 1);
        stabFuseTicks = config.getInt("stab.fuse-ticks", 1);
        stabWobble = config.getDouble("stab.wobble", 0.4);
        stabMaxRange = config.getDouble("stab.max-range", 144.0);

        airliftEnabled = config.getBoolean("airlift.enabled", true);
        airliftTitleEnabled = config.getBoolean("airlift.title-enabled", true);
        airliftChatEnabled = config.getBoolean("airlift.chat-enabled", true);
        airliftSoundEnabled = config.getBoolean("airlift.sound-enabled", true);
        airliftAnnounceEveryMinute = config.getBoolean("airlift.announce-every-minute", true);
        airliftRequirePermission = config.getBoolean("airlift.require-permission", true);
        airliftAllowMultiple = config.getBoolean("airlift.allow-multiple", false);

        hideNametags = config.getBoolean("nametags.hide-enabled", true);
    }

    public long getRegenDelayMinutes() {
        return regenDelayMinutes;
    }

    public int getStabTntPerLayer() {
        return stabTntPerLayer;
    }

    public int getStabMinDepth() {
        return stabMinDepth;
    }

    public int getStabMaxDepth() {
        return stabMaxDepth;
    }

    public int getStabFuseTicks() {
        return stabFuseTicks;
    }

    public double getStabWobble() {
        return stabWobble;
    }

    public double getStabMaxRange() {
        return stabMaxRange;
    }

    public boolean isAirliftEnabled() {
        return airliftEnabled;
    }

    public boolean isAirliftTitleEnabled() {
        return airliftTitleEnabled;
    }

    public boolean isAirliftChatEnabled() {
        return airliftChatEnabled;
    }

    public boolean isAirliftSoundEnabled() {
        return airliftSoundEnabled;
    }

    public boolean isAirliftAnnounceEveryMinute() {
        return airliftAnnounceEveryMinute;
    }

    public boolean isAirliftRequirePermission() {
        return airliftRequirePermission;
    }

    public boolean isAirliftAllowMultiple() {
        return airliftAllowMultiple;
    }

    public boolean isHideNametags() {
        return hideNametags;
    }
}
