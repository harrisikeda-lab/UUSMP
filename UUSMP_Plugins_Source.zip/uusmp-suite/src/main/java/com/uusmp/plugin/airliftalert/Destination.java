package com.uusmp.plugin.airliftalert;

/**
 * A destination is primarily just a display name. World/x/y/z are only
 * present when the admin typed a name that matches one configured in
 * destinations.yml — custom, never-configured names are equally valid and
 * simply have no coordinates attached (reserved for future use, e.g. map
 * markers; nothing in this plugin currently reads them beyond display).
 */
public class Destination {

    private final String name;
    private final String world;
    private final Double x;
    private final Double y;
    private final Double z;

    public Destination(String name) {
        this(name, null, null, null, null);
    }

    public Destination(String name, String world, Double x, Double y, Double z) {
        this.name = name;
        this.world = world;
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public String getName() {
        return name;
    }

    public String getWorld() {
        return world;
    }

    public Double getX() {
        return x;
    }

    public Double getY() {
        return y;
    }

    public Double getZ() {
        return z;
    }

    public boolean hasCoordinates() {
        return world != null && x != null && y != null && z != null;
    }
}
