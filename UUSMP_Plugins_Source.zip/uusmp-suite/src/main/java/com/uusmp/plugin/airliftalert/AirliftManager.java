package com.uusmp.plugin.airliftalert;

import java.util.ArrayList;
import java.util.List;

import net.kyori.adventure.title.Title;

import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import com.uusmp.plugin.config.SuiteConfig;
import org.bukkit.scheduler.BukkitTask;

/**
 * Owns the single active airlift (if any) and its announcement scheduling.
 *
 * Performance note: this does NOT run a repeating per-tick or per-second
 * task. /airlift status computes remaining time on demand from a stored end
 * timestamp, and each per-minute countdown announcement is one lightweight
 * one-shot runTaskLater call scheduled up front — for a 5-minute airlift
 * that's 4 total scheduled callbacks for the whole countdown, not 300 (one
 * per second) or 6000 (one per tick).
 */
public class AirliftManager {

    private final JavaPlugin plugin;
    private final SuiteConfig config;
    private final MessagesConfig messages;
    private final SoundsConfig sounds;
    private final DestinationsConfig destinations;
    private final AirliftStateStore stateStore;

    private AirliftSession session;
    private final List<BukkitTask> scheduledTasks = new ArrayList<>();

    public AirliftManager(JavaPlugin plugin, SuiteConfig config, MessagesConfig messages,
                           SoundsConfig sounds, DestinationsConfig destinations, AirliftStateStore stateStore) {
        this.plugin = plugin;
        this.config = config;
        this.messages = messages;
        this.sounds = sounds;
        this.destinations = destinations;
        this.stateStore = stateStore;
    }

    public boolean start(CommandSender sender, int minutes, String destinationName) {
        if (session != null && session.getState() == AirliftState.COUNTDOWN && !config.isAirliftAllowMultiple()) {
            sender.sendMessage(messages.errorAlreadyActive());
            return false;
        }

        cancelScheduledTasks();

        Destination destination = destinations.resolve(destinationName);
        long now = System.currentTimeMillis();
        long endTime = now + minutes * 60_000L;
        session = new AirliftSession(destination, now, endTime);

        stateStore.save(session);
        broadcastIncoming(destination, minutes);
        if (config.isAirliftAnnounceEveryMinute()) {
            scheduleMarks();
        }
        return true;
    }

    public void arrived(CommandSender sender) {
        if (session == null || session.getState() != AirliftState.COUNTDOWN) {
            sender.sendMessage(messages.errorNoActiveAirlift());
            return;
        }

        cancelScheduledTasks();
        Destination destination = session.getDestination();
        session.setState(AirliftState.ARRIVED);
        broadcastArrived(destination);

        session = null;
        stateStore.clear();
    }

    public void cancel(CommandSender sender) {
        if (session == null || session.getState() != AirliftState.COUNTDOWN) {
            sender.sendMessage(messages.errorNoActiveAirlift());
            return;
        }

        cancelScheduledTasks();
        Destination destination = session.getDestination();
        session.setState(AirliftState.CANCELLED);
        broadcastCancelled(destination);

        session = null;
        stateStore.clear();
    }

    public void status(CommandSender sender) {
        if (session == null || session.getState() != AirliftState.COUNTDOWN) {
            sender.sendMessage(messages.statusInactive());
            return;
        }
        sender.sendMessage(messages.statusActive(session.getDestination().getName(), session.getRemainingSeconds()));
    }

    public List<String> getConfiguredDestinationNames() {
        return destinations.getConfiguredNames();
    }

    /** Called once, after ServerLoadEvent, to resume a countdown that survived a restart. */
    public void restoreFromDisk() {
        AirliftSession restored = stateStore.load();
        if (restored == null) {
            return;
        }

        if (restored.getRemainingSeconds() <= 0) {
            // Expired while the server was down. Don't fire a stale "arrived"-adjacent
            // announcement out of nowhere on boot — just clear it and let staff decide.
            plugin.getLogger().warning("[AirliftAlert] A countdown to " + restored.getDestination().getName()
                    + " expired while the server was offline. Clearing it — start a new one if needed.");
            stateStore.clear();
            return;
        }

        this.session = restored;
        if (config.isAirliftAnnounceEveryMinute()) {
            scheduleMarks();
        }
        plugin.getLogger().info("[AirliftAlert] Resumed countdown to " + restored.getDestination().getName()
                + " (" + MessagesConfig.formatClock(restored.getRemainingSeconds()) + " remaining).");
    }

    public void shutdown() {
        cancelScheduledTasks();
        // Deliberately NOT clearing the state file here — an in-progress countdown
        // should survive a restart, so onDisable must leave airliftstate.yml as-is.
    }

    private void cancelScheduledTasks() {
        for (BukkitTask task : scheduledTasks) {
            task.cancel();
        }
        scheduledTasks.clear();
    }

    private void scheduleMarks() {
        long now = System.currentTimeMillis();
        long endTime = session.getEndTimeMillis();
        long totalMinutes = session.getTotalMinutes();

        for (long m = totalMinutes - 1; m >= 1; m--) {
            long fireAt = endTime - m * 60_000L;
            long delayTicks = (fireAt - now) / 50L;
            if (delayTicks <= 0) {
                continue;
            }
            final int minutesRemaining = (int) m;
            BukkitTask task = plugin.getServer().getScheduler()
                    .runTaskLater(plugin, () -> announceMark(minutesRemaining), delayTicks);
            scheduledTasks.add(task);
        }
    }

    private void announceMark(int minutesRemaining) {
        if (session == null || session.getState() != AirliftState.COUNTDOWN) {
            return;
        }
        Destination destination = session.getDestination();
        String upper = destination.getName().toUpperCase();

        if (config.isAirliftTitleEnabled()) {
            for (Player player : plugin.getServer().getOnlinePlayers()) {
                player.showTitle(Title.title(
                        messages.countdownTitle(upper, minutesRemaining),
                        messages.countdownSubtitle(upper)));
            }
        }
    }

    private void broadcastIncoming(Destination destination, int minutes) {
        String upper = destination.getName().toUpperCase();

        for (Player player : plugin.getServer().getOnlinePlayers()) {
            if (config.isAirliftTitleEnabled()) {
                player.showTitle(Title.title(messages.incomingTitle(upper), messages.incomingSubtitle(upper)));
            }
            if (config.isAirliftChatEnabled()) {
                player.sendMessage(messages.incomingChat(destination.getName(), minutes));
            }
            if (config.isAirliftSoundEnabled()) {
                player.playSound(sounds.incoming());
            }
        }
    }

    private void broadcastArrived(Destination destination) {
        String upper = destination.getName().toUpperCase();

        for (Player player : plugin.getServer().getOnlinePlayers()) {
            if (config.isAirliftTitleEnabled()) {
                player.showTitle(Title.title(messages.arrivedTitle(upper), messages.arrivedSubtitle(upper)));
            }
            if (config.isAirliftChatEnabled()) {
                player.sendMessage(messages.arrivedChat(destination.getName()));
            }
            if (config.isAirliftSoundEnabled()) {
                player.playSound(sounds.arrived());
            }
        }
    }

    private void broadcastCancelled(Destination destination) {
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            if (config.isAirliftTitleEnabled()) {
                player.showTitle(Title.title(messages.cancelledTitle(), net.kyori.adventure.text.Component.text("")));
            }
            if (config.isAirliftChatEnabled()) {
                player.sendMessage(messages.cancelledChatWithDestination(destination.getName()));
            }
            if (config.isAirliftSoundEnabled()) {
                player.playSound(sounds.cancelled());
            }
        }
    }
}
