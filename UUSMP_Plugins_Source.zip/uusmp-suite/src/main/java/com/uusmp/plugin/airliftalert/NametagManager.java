package com.uusmp.plugin.airliftalert;

import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

/**
 * Unrelated to airlifts specifically — a standalone, always-on toggle
 * (nametags.hide-enabled in config.yml) that hides every player's nametag
 * for as long as this plugin is enabled, using a single scoreboard team with
 * NAME_TAG_VISIBILITY=NEVER. On disable, the team is unregistered so
 * nametags return to normal rather than staying hidden if the plugin is
 * removed.
 */
public class NametagManager {

    private static final String TEAM_NAME = "airliftalert_hidden";

    private final JavaPlugin plugin;
    private Team team;

    public NametagManager(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void enable() {
        Scoreboard scoreboard = plugin.getServer().getScoreboardManager().getMainScoreboard();
        team = scoreboard.getTeam(TEAM_NAME);
        if (team == null) {
            team = scoreboard.registerNewTeam(TEAM_NAME);
        }
        team.setOption(Team.Option.NAME_TAG_VISIBILITY, Team.OptionStatus.NEVER);

        for (Player player : plugin.getServer().getOnlinePlayers()) {
            addPlayer(player);
        }
    }

    public void addPlayer(Player player) {
        if (team != null && !team.hasEntry(player.getName())) {
            team.addEntry(player.getName());
        }
    }

    public void disable() {
        if (team != null) {
            team.unregister();
            team = null;
        }
    }
}
