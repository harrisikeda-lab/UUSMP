package com.stasis.plugin;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.FishHook;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

public class BobberEntityManager {

    // Tag key written onto the physical fishing rod ItemStack the first time it is
    // cast. This gives each individual rod its own invisible ID, so a cast/reel-in
    // pair is only ever matched against the rod that was actually used, not any
    // fishing rod the player happens to be holding.
    private static final String ROD_ID_KEY = "stasis_rod_id";

    private final StasisPlugin plugin;
    private final Map<String, ArmorStand> stands;
    private final Map<String, UUID> hooks;

    public BobberEntityManager(StasisPlugin plugin) {
        this.stands = new HashMap<>();
        this.hooks = new HashMap<>();
        this.plugin = plugin;
    }

    public void onCast(Player player, FishHook hook) {
        String rodId = resolveRodId(player, true);
        if (rodId == null) {
            // Player somehow isn't holding a fishing rod in either hand; nothing to track.
            return;
        }

        ArmorStand old = stands.remove(rodId);
        if (old != null && !old.isDead()) {
            old.remove();
        }

        hooks.put(rodId, hook.getUniqueId());
        plugin.getLogger().info("[Bobber] Cast tracked for " + player.getName());
    }

    public void onReelIn(Player player) {
        String rodId = resolveRodId(player, false);
        if (rodId == null) {
            plugin.getLogger().warning("[Bobber] No stand found for player=" + player.getUniqueId());
            saveData();
            return;
        }

        hooks.remove(rodId);
        ArmorStand stand = stands.remove(rodId);
        if (stand != null && !stand.isDead()) {
            stand.remove();
            plugin.getLogger().info("[Bobber] Stand removed for player=" + player.getUniqueId());
        } else {
            plugin.getLogger().warning("[Bobber] No stand found for player=" + player.getUniqueId());
        }
        saveData();
    }

    public void tick() {
        Iterator<Map.Entry<String, UUID>> it = hooks.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, UUID> entry = it.next();
            String rodId = entry.getKey();
            UUID hookId = entry.getValue();

            if (stands.containsKey(rodId)) {
                continue;
            }

            FishHook hook = findHook(hookId);
            if (hook == null) {
                it.remove();
                continue;
            }

            if (hook.getVelocity().lengthSquared() >= 0.0025D) {
                continue;
            }

            ArmorStand stand = spawnHolder(hook.getLocation());
            stands.put(rodId, stand);
            it.remove();
            plugin.getLogger().info("[Bobber] Stand spawned at " + formatLoc(hook.getLocation()));
            saveData();
        }
    }

    public void saveData() {
        plugin.getDataFolder().mkdirs();
        File file = new File(plugin.getDataFolder(), "holders.yml");
        FileConfiguration config = new YamlConfiguration();

        for (Map.Entry<String, ArmorStand> entry : stands.entrySet()) {
            ArmorStand stand = entry.getValue();
            if (stand == null || stand.isDead()) {
                continue;
            }
            String base = "holders." + entry.getKey();
            Location loc = stand.getLocation();
            config.set(base + ".standUUID", stand.getUniqueId().toString());
            config.set(base + ".world", loc.getWorld().getName());
            config.set(base + ".x", loc.getX());
            config.set(base + ".y", loc.getY());
            config.set(base + ".z", loc.getZ());
        }

        try {
            config.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("[Bobber] Could not save holders.yml: " + e.getMessage());
        }
    }

    public void loadData() {
        File file = new File(plugin.getDataFolder(), "holders.yml");
        if (!file.exists()) {
            return;
        }

        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = config.getConfigurationSection("holders");
        if (section == null) {
            return;
        }

        boolean dirty = false;
        for (String key : section.getKeys(false)) {
            try {
                UUID.fromString(key);
            } catch (IllegalArgumentException e) {
                dirty = true;
                continue;
            }

            ConfigurationSection entry = section.getConfigurationSection(key);
            if (entry == null) {
                continue;
            }

            String worldName = entry.getString("world");
            String standUUID = entry.getString("standUUID");
            double x = entry.getDouble("x");
            double z = entry.getDouble("z");

            if (worldName == null || standUUID == null) {
                dirty = true;
                continue;
            }

            World world = plugin.getServer().getWorld(worldName);
            if (world == null) {
                dirty = true;
                continue;
            }

            Chunk chunk = world.getChunkAt((int) x >> 4, (int) z >> 4);
            if (!chunk.isLoaded()) {
                chunk.load();
            }

            UUID standId;
            try {
                standId = UUID.fromString(standUUID);
            } catch (IllegalArgumentException e) {
                dirty = true;
                continue;
            }

            Entity entity = world.getEntity(standId);
            if (!(entity instanceof ArmorStand)) {
                dirty = true;
                continue;
            }
            ArmorStand stand = (ArmorStand) entity;

            stands.put(key, stand);
            plugin.getLogger().info("[Bobber] Restored stand for " + key);
        }

        if (dirty) {
            saveData();
        }
    }

    public void clearAll() {
        saveData();
        stands.clear();
        hooks.clear();
    }

    private FishHook findHook(UUID hookUUID) {
        for (World world : plugin.getServer().getWorlds()) {
            Entity entity = world.getEntity(hookUUID);
            if (entity instanceof FishHook) {
                return (FishHook) entity;
            }
        }
        return null;
    }

    private ArmorStand spawnHolder(Location location) {
        return location.getWorld().spawn(location, ArmorStand.class, (ArmorStand as) -> {
            as.setVisible(false);
            as.setGravity(false);
            as.setMarker(false);
            as.setPersistent(true);
            as.setInvulnerable(true);
            as.setCollidable(false);
            as.setSilent(true);
            as.setSmall(false);
            as.addScoreboardTag("bobber_holder");
        });
    }

    private String formatLoc(Location loc) {
        return loc.getWorld().getName() + " " + loc.getBlockX() + "," + loc.getBlockY() + "," + loc.getBlockZ();
    }

    /**
     * Reads the invisible ID tag off the fishing rod currently in the player's hand
     * (main hand first, then off hand). If assignIfMissing is true and the rod
     * doesn't have a tag yet, a new one is generated and written onto that exact
     * ItemStack. Returns null if the player isn't holding a fishing rod, or if no
     * tag exists and assignIfMissing is false.
     */
    private String resolveRodId(Player player, boolean assignIfMissing) {
        boolean mainHand = true;
        ItemStack rod = player.getInventory().getItemInMainHand();
        if (rod.getType() != Material.FISHING_ROD) {
            rod = player.getInventory().getItemInOffHand();
            mainHand = false;
        }
        if (rod.getType() != Material.FISHING_ROD) {
            return null;
        }

        ItemMeta meta = rod.getItemMeta();
        if (meta == null) {
            return null;
        }

        NamespacedKey key = new NamespacedKey(plugin, ROD_ID_KEY);
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        String id = pdc.get(key, PersistentDataType.STRING);

        if (id == null) {
            if (!assignIfMissing) {
                return null;
            }
            id = UUID.randomUUID().toString();
            pdc.set(key, PersistentDataType.STRING, id);
            rod.setItemMeta(meta);
            if (mainHand) {
                player.getInventory().setItemInMainHand(rod);
            } else {
                player.getInventory().setItemInOffHand(rod);
            }
        }

        return id;
    }
}
