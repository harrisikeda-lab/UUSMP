package com.stasis.plugin;

import java.util.Objects;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

public class StasisPlugin extends JavaPlugin {

    private BobberEntityManager bobberManager;

    @Override
    public void onEnable() {
        this.bobberManager = new BobberEntityManager(this);
        // NOTE: loadData() is intentionally NOT called here. During server startup,
        // plugins finish onEnable() before all worlds have finished loading, so
        // looking up a world/entity at this point can silently fail and (worse)
        // saveData() being called afterwards would overwrite holders.yml with
        // nothing restored. Instead we load once the whole server (all worlds
        // included) is confirmed up, via ServerLoadEvent below.

        PluginManager pm = getServer().getPluginManager();
        pm.registerEvents(new StasisListener(this), this);

        getServer().getScheduler().runTaskTimer(
                this,
                Objects.requireNonNull(bobberManager)::tick,
                1L,
                1L
        );

        getLogger().info("StasisPlugin enabled.");
    }

    @Override
    public void onDisable() {
        bobberManager.clearAll();
        getLogger().info("StasisPlugin disabled.");
    }

    public BobberEntityManager getBobberManager() {
        return bobberManager;
    }
}
