package com.stasis.plugin;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.server.ServerLoadEvent;

public class StasisListener implements Listener {

    private final BobberEntityManager manager;

    public StasisListener(StasisPlugin plugin) {
        this.manager = plugin.getBobberManager();
    }

    // Fires once the ENTIRE server (all worlds included) has finished starting,
    // both on a fresh startup and after a /reload. This is the earliest safe
    // point to look up worlds/entities and restore holders.yml.
    @EventHandler
    public void onServerLoad(ServerLoadEvent event) {
        manager.loadData();
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerFish(PlayerFishEvent event) {
        switch (event.getState()) {
            case FISHING:
                manager.onCast(event.getPlayer(), event.getHook());
                break;
            case REEL_IN:
                manager.onReelIn(event.getPlayer());
                break;
            default:
                break;
        }
    }
}
