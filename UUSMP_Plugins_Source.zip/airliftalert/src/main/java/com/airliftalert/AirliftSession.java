package com.airliftalert;

public class AirliftSession {

    private final Destination destination;
    private final long startTimeMillis;
    private final long endTimeMillis;
    private AirliftState state;

    public AirliftSession(Destination destination, long startTimeMillis, long endTimeMillis) {
        this.destination = destination;
        this.startTimeMillis = startTimeMillis;
        this.endTimeMillis = endTimeMillis;
        this.state = AirliftState.COUNTDOWN;
    }

    public Destination getDestination() {
        return destination;
    }

    public long getStartTimeMillis() {
        return startTimeMillis;
    }

    public long getEndTimeMillis() {
        return endTimeMillis;
    }

    public AirliftState getState() {
        return state;
    }

    public void setState(AirliftState state) {
        this.state = state;
    }

    public long getTotalMinutes() {
        return Math.round((endTimeMillis - startTimeMillis) / 60000.0);
    }

    public long getRemainingSeconds() {
        return Math.max(0, (endTimeMillis - System.currentTimeMillis()) / 1000);
    }
}
