package com.airliftalert;

public enum AirliftState {
    INACTIVE,
    COUNTDOWN,
    ARRIVED,
    CANCELLED
}
