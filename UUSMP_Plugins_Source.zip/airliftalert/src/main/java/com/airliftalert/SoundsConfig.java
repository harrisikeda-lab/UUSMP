package com.airliftalert;

import java.io.File;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.sound.Sound;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * sounds.yml — one sound key per announcement type. Kept separate from
 * messages.yml so swapping a sound never risks a typo breaking message text.
 */
public class SoundsConfig {

    private final JavaPlugin plugin;
    private YamlConfiguration yaml;

    public SoundsConfig(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        plugin.saveResource("sounds.yml", false);
        File file = new File(plugin.getDataFolder(), "sounds.yml");
        yaml = YamlConfiguration.loadConfiguration(file);
    }

    private Sound sound(String path, String fallbackKey) {
        String keyString = yaml.getString(path);
        if (keyString == null) {
            keyString = fallbackKey;
        }
        return Sound.sound(Key.key(keyString), Sound.Source.MASTER, 1.0f, 1.0f);
    }

    public Sound incoming() {
        return sound("incoming", "minecraft:entity.ender_dragon.growl");
    }

    public Sound arrived() {
        return sound("arrived", "minecraft:entity.player.levelup");
    }

    public Sound cancelled() {
        return sound("cancelled", "minecraft:block.anvil.land");
    }
}
