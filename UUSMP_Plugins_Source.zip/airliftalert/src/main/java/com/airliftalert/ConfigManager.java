package com.airliftalert;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * config.yml — the small set of on/off switches and behavior toggles.
 * Kept separate from messages.yml/sounds.yml/destinations.yml so an admin
 * tuning "should this feature be on" never has to scroll past walls of
 * message text or a long destination list to find it.
 */
public class ConfigManager {

    private final JavaPlugin plugin;

    private boolean enabled;
    private boolean titleEnabled;
    private boolean chatEnabled;
    private boolean soundEnabled;
    private boolean announceEveryMinute;
    private boolean requirePermission;
    private boolean allowMultiple;
    private boolean hideNametags;

    public ConfigManager(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        FileConfiguration config = plugin.getConfig();

        enabled = config.getBoolean("airlift.enabled", true);
        titleEnabled = config.getBoolean("airlift.title-enabled", true);
        chatEnabled = config.getBoolean("airlift.chat-enabled", true);
        soundEnabled = config.getBoolean("airlift.sound-enabled", true);
        announceEveryMinute = config.getBoolean("airlift.announce-every-minute", true);
        requirePermission = config.getBoolean("airlift.require-permission", true);
        allowMultiple = config.getBoolean("airlift.allow-multiple", false);
        hideNametags = config.getBoolean("nametags.hide-enabled", true);
    }

    public boolean isEnabled() {
        return enabled;
    }

    public boolean isTitleEnabled() {
        return titleEnabled;
    }

    public boolean isChatEnabled() {
        return chatEnabled;
    }

    public boolean isSoundEnabled() {
        return soundEnabled;
    }

    public boolean isAnnounceEveryMinute() {
        return announceEveryMinute;
    }

    public boolean isRequirePermission() {
        return requirePermission;
    }

    public boolean isAllowMultiple() {
        return allowMultiple;
    }

    public boolean isHideNametags() {
        return hideNametags;
    }
}
