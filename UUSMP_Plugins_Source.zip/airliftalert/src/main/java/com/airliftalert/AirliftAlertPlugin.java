package com.airliftalert;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.server.ServerLoadEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class AirliftAlertPlugin extends JavaPlugin {

    private ConfigManager configManager;
    private MessagesConfig messagesConfig;
    private SoundsConfig soundsConfig;
    private DestinationsConfig destinationsConfig;
    private AirliftStateStore stateStore;
    private AirliftManager airliftManager;
    private AirliftCommand airliftCommand;
    private NametagManager nametagManager;

    @Override
    public void onEnable() {
        configManager = new ConfigManager(this);
        configManager.load();

        messagesConfig = new MessagesConfig(this);
        messagesConfig.load();

        soundsConfig = new SoundsConfig(this);
        soundsConfig.load();

        destinationsConfig = new DestinationsConfig(this);
        destinationsConfig.load();

        stateStore = new AirliftStateStore(this);

        airliftManager = new AirliftManager(this, configManager, messagesConfig, soundsConfig,
                destinationsConfig, stateStore);
        airliftCommand = new AirliftCommand(airliftManager, configManager, messagesConfig);
        nametagManager = new NametagManager(this);

        if (getCommand("airlift") != null) {
            getCommand("airlift").setExecutor(airliftCommand);
            getCommand("airlift").setTabCompleter(airliftCommand);
        }

        getServer().getPluginManager().registerEvents(new LoadListener(), this);
        getServer().getPluginManager().registerEvents(new JoinListener(), this);

        getLogger().info("AirliftAlert enabled.");
    }

    @Override
    public void onDisable() {
        if (airliftManager != null) {
            airliftManager.shutdown();
        }
        if (nametagManager != null) {
            nametagManager.disable();
        }
        getLogger().info("AirliftAlert disabled.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        // Registered directly via getCommand(...).setExecutor(...) in onEnable, so this
        // fallback should never actually be hit — kept only as a defensive backstop.
        if (label.equalsIgnoreCase("airlift") && airliftCommand != null) {
            return airliftCommand.onCommand(sender, command, label, args);
        }
        return false;
    }

    // Restoring a persisted countdown needs worlds/players available, and looking
    // those up during onEnable() is unsafe — see the other plugins in this
    // codebase for the same lesson learned the hard way. ServerLoadEvent fires
    // only after the whole server (all worlds included) is confirmed up. The
    // nametag team is set up here too, for the same reason and for consistency
    // (this also naturally covers anyone already online after a /reload).
    private class LoadListener implements Listener {
        @EventHandler
        public void onServerLoad(ServerLoadEvent event) {
            airliftManager.restoreFromDisk();
            if (configManager.isHideNametags()) {
                nametagManager.enable();
            }
        }
    }

    // Catches players who join after server startup, so their nametag gets
    // hidden too without needing a repeating scan of all online players.
    private class JoinListener implements Listener {
        @EventHandler
        public void onPlayerJoin(PlayerJoinEvent event) {
            if (configManager.isHideNametags()) {
                nametagManager.addPlayer(event.getPlayer());
            }
        }
    }
}
