package com.orbitalrailgun.plugin;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

public class OrbitalRailgunPlugin extends JavaPlugin {

    @Override
    public void onEnable() {
        PluginManager pm = getServer().getPluginManager();
        pm.registerEvents(new RailgunListener(this), this);
        getLogger().info("OrbitalRailgunPlugin enabled.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        Player player = (Player) sender;

        if (label.equalsIgnoreCase("stabshot")) {
            player.getInventory().addItem(RodFactory.createRod(this, RodFactory.RodType.STABSHOT));
            sender.sendMessage("Gave you a stabshot rod.");
            return true;
        }
        if (label.equalsIgnoreCase("nukeshot")) {
            player.getInventory().addItem(RodFactory.createRod(this, RodFactory.RodType.NUKESHOT));
            sender.sendMessage("Gave you a nukeshot rod.");
            return true;
        }
        return false;
    }
}
