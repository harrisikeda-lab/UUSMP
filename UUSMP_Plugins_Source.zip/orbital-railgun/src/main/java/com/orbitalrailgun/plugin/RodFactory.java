package com.orbitalrailgun.plugin;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

public class RodFactory {

    // Tag key used to identify a rod as a railgun rod, and which kind it is.
    static final String TYPE_KEY = "railgun_type";

    public enum RodType {
        STABSHOT("stabshot"),
        NUKESHOT("nukeshot");

        final String id;

        RodType(String id) {
            this.id = id;
        }
    }

    public static ItemStack createRod(OrbitalRailgunPlugin plugin, RodType type) {
        ItemStack rod = new ItemStack(Material.FISHING_ROD, 1);
        ItemMeta meta = rod.getItemMeta();

        // Modern Adventure API — plain setDisplayName(String) is legacy/deprecated,
        // and doesn't give control over italics the way a Component does.
        meta.displayName(Component.text(type.id).decoration(TextDecoration.ITALIC, true));

        // Full durability, no damage set — an omitted damage component defaults to undamaged.
        Enchantment mending = Registry.ENCHANTMENT.get(NamespacedKey.minecraft("mending"));
        Enchantment unbreaking = Registry.ENCHANTMENT.get(NamespacedKey.minecraft("unbreaking"));
        meta.addEnchant(mending, 1, true);
        meta.addEnchant(unbreaking, 3, true);

        NamespacedKey key = new NamespacedKey(plugin, TYPE_KEY);
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        pdc.set(key, PersistentDataType.STRING, type.id);

        rod.setItemMeta(meta);
        return rod;
    }
}
