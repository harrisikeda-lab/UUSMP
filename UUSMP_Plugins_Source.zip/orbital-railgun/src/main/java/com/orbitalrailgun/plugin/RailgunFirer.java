package com.orbitalrailgun.plugin;

import java.util.Random;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

public class RailgunFirer {

    // Matches the datapack's raycast_limit of 180 steps of 0.8 blocks each.
    private static final double MAX_RANGE = 180 * 0.8;

    // Same ring layout as the datapack's nukeshot.mcfunction, condensed from
    // dozens of hardcoded `summon` lines into data driving a loop.
    private static final double[] NUKE_RING_RADII = {0.15, 0.30, 0.50, 0.70, 0.95, 1.25, 1.55};
    private static final int[] NUKE_RING_COUNTS = {24, 24, 24, 36, 48, 60, 72};
    private static final int NUKE_FUSE_TICKS = 80;
    private static final double NUKE_SPAWN_HEIGHT = 50;

    private static final int STAB_FUSE_TICKS = 1;
    private static final int STAB_MIN_DY = -250;
    private static final int STAB_MAX_DY = 1;
    private static final double STAB_WOBBLE = 0.4;

    private static final Random RANDOM = new Random();

    private RailgunFirer() {
    }

    public static void fireStabshot(OrbitalRailgunPlugin plugin, Player player) {
        Location target = raycastTarget(player);
        if (target == null) {
            return;
        }
        World world = target.getWorld();

        player.playSound(player.getEyeLocation(), Sound.ITEM_SHIELD_BREAK, 1.0f, 1.0f);

        for (int dy = STAB_MAX_DY; dy >= STAB_MIN_DY; dy--) {
            double ox = (RANDOM.nextDouble() - 0.5) * STAB_WOBBLE;
            double oz = (RANDOM.nextDouble() - 0.5) * STAB_WOBBLE;
            Location loc = target.clone().add(ox, dy, oz);
            world.spawn(loc, TNTPrimed.class, tnt -> tnt.setFuseTicks(STAB_FUSE_TICKS));
        }
    }

    public static void fireNukeshot(OrbitalRailgunPlugin plugin, Player player) {
        Location target = raycastTarget(player);
        if (target == null) {
            return;
        }
        World world = target.getWorld();
        Location spawnBase = target.clone().add(0, NUKE_SPAWN_HEIGHT, 0);

        player.playSound(player.getEyeLocation(), Sound.ITEM_SHIELD_BREAK, 1.0f, 1.0f);

        for (int ring = 0; ring < NUKE_RING_RADII.length; ring++) {
            double radius = NUKE_RING_RADII[ring];
            int count = NUKE_RING_COUNTS[ring];
            for (int i = 0; i < count; i++) {
                double angle = 2 * Math.PI * i / count;
                double vx = radius * Math.cos(angle);
                double vz = radius * Math.sin(angle);
                world.spawn(spawnBase, TNTPrimed.class, tnt -> {
                    tnt.setFuseTicks(NUKE_FUSE_TICKS);
                    tnt.setVelocity(new Vector(vx, 0, vz));
                });
            }
        }

        // A short vertical trail of particles from the spawn point down to the
        // target, standing in for the datapack's (excessive, ~250-call) particle spam.
        double totalDrop = NUKE_SPAWN_HEIGHT;
        int steps = 12;
        for (int i = 0; i <= steps; i++) {
            double y = NUKE_SPAWN_HEIGHT - (totalDrop * i / steps);
            world.spawnParticle(Particle.EXPLOSION_EMITTER, target.clone().add(0, y, 0), 1);
        }
    }

    private static Location raycastTarget(Player player) {
        Location eye = player.getEyeLocation();
        World world = eye.getWorld();
        if (world == null) {
            return null;
        }

        RayTraceResult result = world.rayTraceBlocks(eye, eye.getDirection(), MAX_RANGE);
        if (result != null && result.getHitPosition() != null) {
            Vector hit = result.getHitPosition();
            return new Location(world, hit.getX(), hit.getY(), hit.getZ());
        }

        // Nothing in range — fall back to max range along the look direction,
        // matching the datapack's "MAX RANGE" branch.
        Vector dir = eye.getDirection();
        return new Location(world,
                eye.getX() + dir.getX() * MAX_RANGE,
                eye.getY() + dir.getY() * MAX_RANGE,
                eye.getZ() + dir.getZ() * MAX_RANGE);
    }
}
