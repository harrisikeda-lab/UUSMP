package com.orbitalrailgun.plugin;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

public class RailgunListener implements Listener {

    private final OrbitalRailgunPlugin plugin;

    public RailgunListener(OrbitalRailgunPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerFish(PlayerFishEvent event) {
        if (event.getState() != PlayerFishEvent.State.FISHING) {
            return;
        }

        Player player = event.getPlayer();
        String type = resolveRodType(player);
        if (type == null) {
            return;
        }

        if (type.equals(RodFactory.RodType.STABSHOT.id)) {
            RailgunFirer.fireStabshot(plugin, player);
        } else if (type.equals(RodFactory.RodType.NUKESHOT.id)) {
            RailgunFirer.fireNukeshot(plugin, player);
        }
    }

    private String resolveRodType(Player player) {
        ItemStack rod = player.getInventory().getItemInMainHand();
        if (rod.getType() != Material.FISHING_ROD) {
            rod = player.getInventory().getItemInOffHand();
        }
        if (rod.getType() != Material.FISHING_ROD) {
            return null;
        }

        ItemMeta meta = rod.getItemMeta();
        if (meta == null) {
            return null;
        }

        NamespacedKey key = new NamespacedKey(plugin, RodFactory.TYPE_KEY);
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        return pdc.get(key, PersistentDataType.STRING);
    }
}
