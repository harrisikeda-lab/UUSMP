# Objectives are prefixed uusmp_ so they can't collide with another datapack's scoreboard
scoreboard objectives add uusmp_raycast_limit dummy
scoreboard objectives add uusmp_stabshot_timer dummy
scoreboard objectives add uusmp_nukeshot_timer dummy

# Make sure everyone already online is armed with the trigger advancements
advancement grant @a only nuke:use_stabshot
advancement grant @a only nuke:use_nukeshot
