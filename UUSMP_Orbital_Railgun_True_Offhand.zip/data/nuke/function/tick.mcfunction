# Keep every online player armed with the fire-on-use advancements (also catches new joins)
advancement grant @a only nuke:use_stabshot
advancement grant @a only nuke:use_nukeshot

execute as @e[type=block_display,tag=uusmp_stabshot] run scoreboard players add @s uusmp_stabshot_timer 1
execute as @e[type=block_display,tag=uusmp_stabshot,scores={uusmp_stabshot_timer=20..}] at @s run function nuke:orbital_strike_cannon/stabshot
execute as @e[type=block_display,tag=uusmp_stabshot,scores={uusmp_stabshot_timer=20..}] run kill @s

execute as @e[type=block_display,tag=uusmp_nukeshot] run scoreboard players add @s uusmp_nukeshot_timer 1
execute as @e[type=block_display,tag=uusmp_nukeshot,scores={uusmp_nukeshot_timer=20..}] at @s run function nuke:orbital_strike_cannon/nukeshot
execute as @e[type=block_display,tag=uusmp_nukeshot,scores={uusmp_nukeshot_timer=20..}] run kill @s
