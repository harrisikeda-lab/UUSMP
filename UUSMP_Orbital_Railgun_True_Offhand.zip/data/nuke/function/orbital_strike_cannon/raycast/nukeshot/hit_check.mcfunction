# HIT BLOCK
execute unless block ~ ~ ~ air run summon block_display ~ ~ ~ {interpolation_duration:0,block_state:{Name:"minecraft:air"},Tags:["uusmp_nukeshot"]}
execute unless block ~ ~ ~ air run return 0

# MAX RANGE
execute if score @s uusmp_raycast_limit matches 180.. run summon block_display ~ ~ ~ {interpolation_duration:0,block_state:{Name:"minecraft:air"},Tags:["uusmp_nukeshot"]}
execute if score @s uusmp_raycast_limit matches 180.. run return 0

# CONTINUE
scoreboard players add @s uusmp_raycast_limit 1
execute positioned ^ ^ ^0.8 run function nuke:orbital_strike_cannon/raycast/nukeshot/hit_check
