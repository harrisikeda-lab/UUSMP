# Re-arm the advancement immediately so this player can trigger it again next use
advancement revoke @s only nuke:use_stabshot

scoreboard players reset @s uusmp_raycast_limit
playsound item.shield.break player @a[distance=..10] ~ ~ ~ 30 1
execute anchored eyes run function nuke:orbital_strike_cannon/raycast/stabshot/raycast
