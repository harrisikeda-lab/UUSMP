give @s red_shulker_box[container=[\
{slot:0,item:{id:"minecraft:fishing_rod",count:1,components:{"minecraft:custom_data":{stabshot:1b},"minecraft:custom_name":'stabshot',"minecraft:rarity":"rare","minecraft:damage":63}}}, \
{slot:1,item:{id:"minecraft:fishing_rod",count:1,components:{"minecraft:custom_data":{stabshot:1b},"minecraft:custom_name":'stabshot',"minecraft:rarity":"rare","minecraft:damage":63}}}, \
{slot:2,item:{id:"minecraft:fishing_rod",count:1,components:{"minecraft:custom_data":{stabshot:1b},"minecraft:custom_name":'stabshot',"minecraft:rarity":"rare","minecraft:damage":63}}}, \
{slot:3,item:{id:"minecraft:fishing_rod",count:1,components:{"minecraft:custom_data":{stabshot:1b},"minecraft:custom_name":'stabshot',"minecraft:rarity":"rare","minecraft:damage":63}}}, \
{slot:4,item:{id:"minecraft:fishing_rod",count:1,components:{"minecraft:custom_data":{stabshot:1b},"minecraft:custom_name":'stabshot',"minecraft:rarity":"rare","minecraft:damage":63}}}, \
{slot:5,item:{id:"minecraft:fishing_rod",count:1,components:{"minecraft:custom_data":{stabshot:1b},"minecraft:custom_name":'stabshot',"minecraft:rarity":"rare","minecraft:damage":63}}}, \
{slot:6,item:{id:"minecraft:fishing_rod",count:1,components:{"minecraft:custom_data":{stabshot:1b},"minecraft:custom_name":'stabshot',"minecraft:rarity":"rare","minecraft:damage":63}}}, \
{slot:7,item:{id:"minecraft:fishing_rod",count:1,components:{"minecraft:custom_data":{stabshot:1b},"minecraft:custom_name":'stabshot',"minecraft:rarity":"rare","minecraft:damage":63}}}, \
{slot:8,item:{id:"minecraft:fishing_rod",count:1,components:{"minecraft:custom_data":{stabshot:1b},"minecraft:custom_name":'stabshot',"minecraft:rarity":"rare","minecraft:damage":63}}}, \
{slot:9,item:{id:"minecraft:fishing_rod",count:1,components:{"minecraft:custom_data":{stabshot:1b},"minecraft:custom_name":'stabshot',"minecraft:rarity":"rare","minecraft:damage":63}}}, \
{slot:10,item:{id:"minecraft:fishing_rod",count:1,components:{"minecraft:custom_data":{stabshot:1b},"minecraft:custom_name":'stabshot',"minecraft:rarity":"rare","minecraft:damage":63}}}, \
{slot:11,item:{id:"minecraft:fishing_rod",count:1,components:{"minecraft:custom_data":{stabshot:1b},"minecraft:custom_name":'stabshot',"minecraft:rarity":"rare","minecraft:damage":63}}}, \
{slot:12,item:{id:"minecraft:fishing_rod",count:1,components:{"minecraft:custom_data":{nukeshot:1b},"minecraft:custom_name":'nukeshot',"minecraft:rarity":"rare","minecraft:damage":63}}}, \
{slot:13,item:{id:"minecraft:fishing_rod",count:1,components:{"minecraft:custom_data":{nukeshot:1b},"minecraft:custom_name":'nukeshot',"minecraft:rarity":"rare","minecraft:damage":63}}}, \
{slot:14,item:{id:"minecraft:fishing_rod",count:1,components:{"minecraft:custom_data":{nukeshot:1b},"minecraft:custom_name":'nukeshot',"minecraft:rarity":"rare","minecraft:damage":63}}}, \
{slot:15,item:{id:"minecraft:fishing_rod",count:1,components:{"minecraft:custom_data":{nukeshot:1b},"minecraft:custom_name":'nukeshot',"minecraft:rarity":"rare","minecraft:damage":63}}}, \
{slot:16,item:{id:"minecraft:fishing_rod",count:1,components:{"minecraft:custom_data":{nukeshot:1b},"minecraft:custom_name":'nukeshot',"minecraft:rarity":"rare","minecraft:damage":63}}}, \
{slot:17,item:{id:"minecraft:fishing_rod",count:1,components:{"minecraft:custom_data":{nukeshot:1b},"minecraft:custom_name":'nukeshot',"minecraft:rarity":"rare","minecraft:damage":63}}}, \
{slot:18,item:{id:"minecraft:fishing_rod",count:1,components:{"minecraft:custom_data":{nukeshot:1b},"minecraft:custom_name":'nukeshot',"minecraft:rarity":"rare","minecraft:damage":63}}}, \
{slot:19,item:{id:"minecraft:fishing_rod",count:1,components:{"minecraft:custom_data":{nukeshot:1b},"minecraft:custom_name":'nukeshot',"minecraft:rarity":"rare","minecraft:damage":63}}}, \
{slot:20,item:{id:"minecraft:fishing_rod",count:1,components:{"minecraft:custom_data":{nukeshot:1b},"minecraft:custom_name":'nukeshot',"minecraft:rarity":"rare","minecraft:damage":63}}}, \
{slot:21,item:{id:"minecraft:fishing_rod",count:1,components:{"minecraft:custom_data":{nukeshot:1b},"minecraft:custom_name":'nukeshot',"minecraft:rarity":"rare","minecraft:damage":63}}}, \
{slot:22,item:{id:"minecraft:fishing_rod",count:1,components:{"minecraft:custom_data":{nukeshot:1b},"minecraft:custom_name":'nukeshot',"minecraft:rarity":"rare","minecraft:damage":63}}}, \
{slot:23,item:{id:"minecraft:fishing_rod",count:1,components:{"minecraft:custom_data":{nukeshot:1b},"minecraft:custom_name":'nukeshot',"minecraft:rarity":"rare","minecraft:damage":63}}} \
]]